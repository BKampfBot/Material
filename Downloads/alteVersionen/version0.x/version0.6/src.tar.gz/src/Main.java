//      Main.java
//      
//      Copyright 2009 Georg Limbach <georf@georf.de>
//      
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 2 of the License, or
//      (at your option) any later version.
//      
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//      
//      You should have received a copy of the GNU General Public License
//      along with this program; if not, write to the Free Software
//      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//      MA 02110-1301, USA.


import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import json.*;



public class Main {

	private static int configMinMoney;
	private static int configOpponentLv;
	private static int configOpponentGuild;
	private static int configFieldService;
	private static int configFightAfter;
	private static String configUserName;
	private static String configUserPassword;
	
	
	public static DefaultHttpClient httpclient;
	
	private static boolean debug = true;
	private static int myLevel = 1;
	private static int myWinMoney = 0;
	private static int myLostMoney = 0;
	private static int myFights = 0;
	private static int myMaxLp = 0;
	private static int myLp = 0;
	private static String myRace = "";
	
	private static Calendar nextFight;
	private static String nextFightUrl = null;
	private static String nextFightName = null;
	private static int nextFightCount = 0;
	private static String nextTask = "";
	private static boolean firstQuest = true;
	
	private static Robot rb;
	private static Timer timer;
	
	private static int badTries = 0;
	
	private static Main help;
	private static int configFieldServiceDifficult;
	
	public static void main(String[] args) {
		
		// Advise
		System.out.println("http://www.georf.de/");
	
		Main.httpclient = new DefaultHttpClient();
		
		final HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		//HttpProtocolParams.setContentCharset(params, UTF_8);
		HttpProtocolParams.setUseExpectContinue(params, false); // solves the '417' issue
		HttpProtocolParams.setUserAgent(params, "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.1.5) Gecko/20091109 Ubuntu/9.10 (karmic) Firefox/3.5.5");
		//HttpProtocolParams.setHttpElementCharset(params, )
		
		Main.httpclient.setParams(params);
	
		Main.httpclient.getParams().setParameter(ClientPNames.COOKIE_POLICY,  
				CookiePolicy.BROWSER_COMPATIBILITY); 
	
		Main.help = new Main();
		
		// Read properties file.
	    Properties properties = new Properties();
	    try {
	        properties.load(new FileInputStream("Bundeskampf.config"));
	        Main.configUserName = properties.getProperty("username");
	        Main.configUserPassword = properties.getProperty("password");
	        Main.configMinMoney = Integer.parseInt(properties.getProperty("minMoney"));
	        Main.configOpponentLv = Integer.parseInt(properties.getProperty("opponentLv"));
	        Main.configOpponentGuild = Integer.parseInt(properties.getProperty("opponentGuild"));
	        Main.configFieldService = Integer.parseInt(properties.getProperty("aussendienst"));
	        Main.configFightAfter = Integer.parseInt(properties.getProperty("angriffDanach"));
	        Main.configFieldServiceDifficult = Integer.parseInt(properties.getProperty("aussendienstGrad"));
	        if (Integer.parseInt(properties.getProperty("debug"))==0) {
	        	Main.debug = false;
	        } else {
	        	Main.debug = true;
	        }
	    } catch (IOException e) {
	    	Main.debug("Can't read config.");
	    	Main.debug("Will exit.");
	    	System.exit(1);
	    }
	
		help.new RedirectedFrame(Main.debug,(args.length>0 && args[0] == "console"));
		
		
		try {
			Main.rb = new Robot();
			Main.timer = new Timer();
		} catch (AWTException e) {
			e.printStackTrace();
	    	Main.debug("Can't configurate the robot engine.");
	    	Main.debug("Will exit.");
	    	System.exit(1);
		}
	
		Main.nextFight = new GregorianCalendar();
	
		Main.login(Main.configUserName, Main.configUserPassword);
		
		if (Main.configFieldService == 1) {
			Main.FieldService();
		} else {
			Main.WildeKeilerei();	
		}			
	}
	
	public static void putMyStatus() {
		System.out.print("----------------------\n" +
				"My Avatar:\n"+
				"My fights: \t"+Main.myFights+"\n"+
				"My win Money: \t"+Main.myWinMoney+"\n"+
				"My lost Money: \t"+Main.myLostMoney+"\n"+
				"My level: \t"+Main.myLevel+"\n"+
				"My livepoints:\t"+Main.myLp+"/"+Main.myMaxLp+"\n"+
				"My race:\t"+Main.myRace+"\n"+
				"----------------------\n");
	}

	public class doTask extends TimerTask {
		public void run() {
			if (Main.nextTask == "") {
				Main.WildeKeilerei();
			} else if (Main.nextTask == "questFinish") {
				Main.FieldServiceFinish();
			} else if (Main.nextTask == "quest") {
				Main.FieldService();
			}
		}
	}

	public static void atWork(String s) {
		if(s.indexOf("/Bilderx/arbeiten.jpg")!=-1)
			System.out.println("Info: Du bist gerade am Arbeiten");
		else if (s.indexOf("/Bilderx/train.jpg")!=-1)
			System.out.println("Info: Du bist gerade am Trainieren");
	}
	
	public static void fight(String attack, String name) {
		try {
			Main.sinnlos("http://www.bundeskampf.com/fights/fight");
			Main.rb.delay(500);
		
			Main.debug("fight with "+name);
			Main.sinnlos("http://www.bundeskampf.com"+attack);
			Main.rb.delay(500);
			
			HttpGet httpget = new HttpGet("http://www.bundeskampf.com/fights/fightData");
	
			// Create a response handler
			HttpResponse response = Main.httpclient.execute(httpget);
		    
			HttpEntity resEntity = response.getEntity();
	
			if (resEntity != null) {
				JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
				JSONObject fight = new JSONObject(js);
				if (resEntity != null) {
					resEntity.consumeContent();
				}
	
				httpget = new HttpGet("http://www.bundeskampf.com"+fight.getString("url").replace("/results/","/getResults/"));
	
				// Create a response handler
				response = Main.httpclient.execute(httpget);
			    
				resEntity = response.getEntity();
	
				if (resEntity != null) {
					String s = EntityUtils.toString(resEntity);
					//Main.debug("Fightresult: "+s+"\n____\n");
					js = new JSONTokener(s);
					fight = new JSONObject(js);
					JSONObject res = fight.getJSONObject("results");
					JSONObject p1 = res.getJSONObject("p1");
					
					if(res.getBoolean("fightWasWon")){
						Main.debug("Fight won");
						Main.myWinMoney += p1.getInt("gold");	
						
						// Gegner merken, für nächstn Angriff
						if (Main.configMinMoney < p1.getInt("gold")) {
							Main.nextFightCount++;
							Main.nextFightName = name;
							Main.nextFightUrl = attack;
						} else {
							Main.nextFightCount = 0;
							Main.nextFightName = null;
							Main.nextFightUrl = null;
						}
					} else {
						Main.debug("Fight lost");
						Main.myLostMoney = p1.getInt("gold");	
						Main.nextFightCount = 0;
						Main.nextFightName = null;
						Main.nextFightUrl = null;							
					}
					
					Main.myLevel = Integer.parseInt(fight.getString("mylevel"));
					Main.myLp =  Integer.parseInt(p1.getString("lp"));
					Main.myMaxLp =  Integer.parseInt(p1.getString("maxLp"));
	
					JSONObject time = fight.getJSONObject("aTime");
					Calendar d = new GregorianCalendar(Integer.parseInt(time.getString("toYear")),
									Integer.parseInt(time.getString("toMonth"))-1,
									Integer.parseInt(time.getString("toDay")),
									Integer.parseInt(time.getString("toHour")),
									Integer.parseInt(time.getString("toMinute")),
									Integer.parseInt(time.getString("toSecond")));
					
					Main.myFights++;
					Main.nextFight = d;
					
					if (resEntity != null) {
						resEntity.consumeContent();
					}
				}

				
				Main.WildeKeilerei();
				return;
			}
		} catch (Exception e) {
			Main.nextFightCount = 0;
			Main.nextFightName = null;
			Main.nextFightUrl = null;
			Main.WildeKeilerei();
			return;
		}

	}
	
	
	public static void WildeKeilerei() {
		
		Main.putMyStatus();
		
		if (Main.nextFight.after(new GregorianCalendar())) {
			long i = Main.nextFight.getTimeInMillis()-GregorianCalendar.getInstance().getTimeInMillis();
			i+=90000;
			timer.schedule(Main.help.new doTask(), i);
			int z = (int) (i/60000);
			Main.debug("try again later, in "+z+" Min ("+Main.nextFight.getTime().toString()+")");
			return;
		}
		
		if (Main.nextFightUrl != null && Main.nextFightCount < 11) {
			Main.fight(Main.nextFightUrl, Main.nextFightName);
			return;
		}
		
		Main.debug("get WildeKeilerei Liste");
		Main.sinnlos("http://www.bundeskampf.com/fights/start");
		try {
			JSONArray arr = Main.getWildeKeilereiListe();
			JSONObject now;
			if (arr.length() > 0) {
				for (int i=0; i<arr.length(); i++) {
					now = arr.getJSONObject(i);
					boolean guild;
					try {
						now.getInt("guild");
						guild = false;
					} catch (JSONException e) {
						guild = true;
					}
					if (now.getInt("level") == Main.myLevel+Main.configOpponentLv) {
						if (now.getString("race").compareTo(Main.myRace)!=0) {
							Main.debug(now.toString());
							if (Main.configOpponentGuild == 0 || 
									(guild && Main.configOpponentGuild == 1) ||
									(!guild && Main.configOpponentGuild == -1)) {
								Main.badTries = 0;
								Main.fight(now.getString("attack"), now.getString("name"));
								return;
							}
						}
					}
				}
				// not found someone
				// try again
				if (Main.badTries > 10) {
					debug("Didn't find someone to fight. Will exit ...");
					return;
				}
				Main.badTries++;
				Main.WildeKeilerei();
				
			} else {
				Main.nextFight = new GregorianCalendar();
				Main.nextFight.add(GregorianCalendar.MINUTE, 1);
				Main.WildeKeilerei();
			}
		}catch(Exception e){
			e.printStackTrace();
			debug("Something went wrong... will try later again...");
			Main.nextFight = new GregorianCalendar();
			Main.nextFight.add(GregorianCalendar.MINUTE, 1);
			Main.WildeKeilerei();
		}

	}
	
	
	private static void FieldServiceFinish() {
		Main.sinnlos("http://www.bundeskampf.com/quests/finish");
		Main.rb.delay(500);
		Main.FieldService();
	}
	
	private static void FieldService() {
		if (Main.firstQuest) {
			Main.firstQuest = false;
			Main.FieldServiceFinish();
			return;
		}
		String url = "http://www.bundeskampf.com/quests/start";
		try {
			HttpGet httpget = new HttpGet(url);
	        
			// Create a response handler
			HttpResponse response = Main.httpclient.execute(httpget);
		    
			HttpEntity resEntity = response.getEntity();

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				if (s.indexOf("/img/images2/max.jpg") != -1) {
					Main.debug("All quests for today are finished");
					if (Main.configFightAfter == 1) {
						Main.debug("Will fight now ...");
						Main.nextTask = "";
						Main.WildeKeilerei();
						return;
					} else {
						return;
					}
				}
				String search = "var quests = ";
				int start = s.indexOf(search);
				if (start == -1) {
					
					
					
					Main.debug("Don't find a quest, will try in 3 min again");
					Main.nextTask = "quest";
					
					Main.atWork(s);
					
					timer.schedule(Main.help.new doTask(), 3*60*1000);
					
					return;
				
				}
				start = s.indexOf('\n',start+search.length());
				start = s.indexOf('\n',start+2);
				int end = s.indexOf("]",start)+1;
				search = s.substring(start,end);
				
				search = "{list:["+search+"}";

				JSONObject o = new JSONObject( new JSONTokener(search));
				JSONObject now = o.getJSONArray("list").getJSONObject(
						Main.configFieldServiceDifficult);
				debug("Take job: \""+now.getString("title")+"\"");

			
				Main.sinnlos("http://www.bundeskampf.com/quests/start/"+now.getInt("questId")+"/0");
				
				Main.rb.delay(500);
			    
				if (resEntity != null) {
					resEntity.consumeContent();
				}
				
				httpget = new HttpGet("http://www.bundeskampf.com/quests/questData");
		        
				// Create a response handler
				response = Main.httpclient.execute(httpget);
			    
				resEntity = response.getEntity();

				if (resEntity != null) {
					s = EntityUtils.toString(resEntity);
					o = new JSONObject(new JSONTokener(s));
					int serverTs = o.getJSONObject("time").getInt("server");
					int endTs = o.getJSONObject("time").getInt("realend");
					
					long i = endTs-serverTs;
					i*=1000;
					i+=30000;
					Main.nextTask = "questFinish";
					
					timer.schedule(Main.help.new doTask(), i);
					int z = (int) (i/60000);
					GregorianCalendar c = new GregorianCalendar();
					c.setTimeInMillis(new GregorianCalendar().getTimeInMillis()+i);
					
					Main.debug("Wait for finish, in "+z+" Min ("+(c.getTime().toString())+")");
					return;
				}
					
			}
			    

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	private static JSONArray getWildeKeilereiListe() {
		String url = "http://www.bundeskampf.com/fights/opponentsListJson";
		try {
			HttpGet httpget = new HttpGet(url);
	        
			// Create a response handler
			HttpResponse response = Main.httpclient.execute(httpget);
		    
			HttpEntity resEntity = response.getEntity();
			JSONArray arr;

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				//debug(s);
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
				arr = ob.getJSONArray("list");
			} else {
				arr = new JSONArray();
			}
			    
			    
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			return arr;

		} catch (Exception e) {
			debug("no list avalibile");
		}
		return new JSONArray();

		
	}
	public static void sinnlos(String url) {
		Main.debug("sinnlos: "+url);
	
		try{
			HttpGet httpget = new HttpGet(url);
	        HttpResponse response = Main.httpclient.execute(httpget);
	        HttpEntity entity = response.getEntity();
	        //Main.debug(EntityUtils.toString(entity));
	        if (entity != null) {
	            entity.consumeContent();
	        }

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	
	public static void getInfo(String s) throws JSONException {
		//Main.debug(s);
		Main.atWork(s);
		int navi2 = s.indexOf("/img/flash/navi_or2.swf");
		//debug("position,navi2:"+navi2);
		navi2 = s.indexOf("flashvars", navi2+1);
		//debug("position,flsh1:"+navi2);
		navi2 = s.indexOf("flashvars", navi2+1);
		//debug("position,flsh2:"+navi2);
		int lineFront = s.indexOf('{', navi2);
		//debug("position,{:"+navi2);
		int lineEnd = s.indexOf(';', lineFront+1);
		//debug("position,;:"+navi2);
		String s2 = s.substring(lineFront+1, lineEnd+1);
		s2 = "{"+s2;
		//debug(s2);
		
		JSONTokener tk = new JSONTokener(s2);
		JSONObject character = new JSONObject(tk);
		Main.myMaxLp = Integer.parseInt(character.getString("max_lp"));
		Main.myLp = Integer.parseInt(character.getString("lp"));
		Main.myLevel = Integer.parseInt(character.getString("lvl"));
		
		s2 = "<b>Bundesland:</b> </span><br/><span style=\"color:#000000; font-size:12px;\">";
		
		lineFront = s.indexOf(s2);
		lineEnd = s.indexOf('<',lineFront+1+s2.length());
		Main.myRace = s.substring(lineFront+s2.length()+1, lineEnd-1);
		Main.myRace = Main.myRace.trim();
		if (Main.myRace.compareToIgnoreCase("Meck.-Vorp.")==0) {
			Main.myRace = "Mecklenburg-Vorpommern";
		}
		return;
	}
	

	public static void login(String nick, String password) {
		Main.debug("Login");
		String loginPage = "http://www.bundeskampf.com/signups/login/";
	
		try{
			HttpGet httpget;
	        HttpResponse response;
	        HttpEntity entity;
	        
	        // Post senden
			HttpPost httppost = new HttpPost(loginPage);
			
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("data[Signup][name]", nick));
			nvps.add(new BasicNameValuePair("data[Signup][pass]", password));
			nvps.add(new BasicNameValuePair("Einloggen.x", "67"));
			nvps.add(new BasicNameValuePair("Einloggen.y", "18"));
			
			httppost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			httppost.addHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			httppost.addHeader("Accept-Language","de-de,de;q=0.8,en-us;q=0.5,en;q=0.3");
			httppost.addHeader("Accept-Encoding","gzip,deflate");
			httppost.addHeader("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
			httppost.addHeader("Keep-Alive","300");
			httppost.addHeader("Referer","http://www.bundeskampf.com/signups/login");
			
			response = Main.httpclient.execute(httppost);
			entity = response.getEntity();
			
			if (entity != null) {
			    entity.consumeContent();
			}
			
			String url ="http://www.bundeskampf.com/characters/index";
			httpget = new HttpGet(url);
			httpget.addHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			httpget.addHeader("Accept-Language","de-de,de;q=0.8,en-us;q=0.5,en;q=0.3");
			httpget.addHeader("Accept-Encoding","gzip,deflate");
			httpget.addHeader("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
			httpget.addHeader("Keep-Alive","300");
			httpget.addHeader("Referer","http://www.bundeskampf.com/signups/login");
	        
			// Create a response handler
			response = Main.httpclient.execute(httpget);
		    
			HttpEntity resEntity = response.getEntity();
			
			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				Main.getInfo(s);				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void debug(String d) {
		if (Main.debug) {
			System.out.println("DEBUG: "+d);
		}
	}

	
	public class RedirectedFrame extends Frame {
		   /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		TextArea aTextArea = new TextArea();
		PrintStream aPrintStream  = 
			new PrintStream(new FilteredStream(new ByteArrayOutputStream()));

		boolean logFile;
		
		RedirectedFrame(boolean logFile, boolean fr) {
			this.logFile = logFile;

			if(!fr) {
				System.setOut(aPrintStream);
				System.setErr(aPrintStream);
				this.setTitle("Terminal");
				this.setSize(500,300);
				this.setLayout(new BorderLayout());
				this.add("Center" , aTextArea);
				this.displayLog();
				
				
				this.addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {
						dispose();
						System.exit(0);
					}
				});
			}
		}

		class FilteredStream extends FilterOutputStream {
			public FilteredStream(OutputStream aStream) {
				super(aStream);
			}

			public void write(byte b[]) throws IOException {
				String aString = new String(b);
				aTextArea.append(aString);
			}

			public void write(byte b[], int off, int len) throws IOException {
				String aString = new String(b , off , len);
				aTextArea.append(aString);
				if (logFile) {
					FileWriter aWriter = new FileWriter("error.log", true);
		            aWriter.write(aString);
		            aWriter.close();
		        }
		    }
		}

		public void displayLog() {
			Dimension dim = getToolkit().getScreenSize();
			Rectangle abounds = getBounds();
			setLocation((dim.width - abounds.width) / 2, (dim.height - abounds.height) / 2);
			setVisible(true);
			requestFocus();
		}
			
	}

}
