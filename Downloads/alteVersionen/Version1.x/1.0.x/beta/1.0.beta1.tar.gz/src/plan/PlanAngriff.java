package plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.BadOpponent;
import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanAngriff extends PlanObject {
	public enum Club { No, Yes, Whatever };
	private Club club;
	private int level;

	private static Opponent[] lowMoney;
	private static int lowMoneyPointer;
	
	private static ArrayList<Opponent> highMoney;
	private static ArrayList<Opponent> bad;
	
	private static Calendar countDate;

	public PlanAngriff(JSONObject object) throws FatalError {
		this.setName("Angriff");
		
		try {
			JSONObject angriff = object.getJSONObject("Angriff");
			
			int c = angriff.getInt("Verein");
			if (c == 0) this.club = Club.Whatever;
			else if (c == 1) this.club = Club.Yes;
			else if (c == -1) this.club = Club.No;
			else new FatalError("Config error: Verein have to be 1,-1 or 0");
			
			this.level = angriff.getInt("Stufe");
		} catch (JSONException e) {
			throw new FatalError("Config error: Angriff config is bad");
		}
	}
	
	public final void run() throws IOException {
		Instance ins = Control.current;
		Output.println(
				"-> Angriff (Verein: " +
				(this.club.equals(Club.Yes)? "Ja":"") +
				(this.club.equals(Club.No)? "Nein":"") +
				(this.club.equals(Club.Whatever)? "Egal":"") +
				", Level: " +
				String.valueOf(this.level + ins.user.getLevel()) +
				")");

		try {
			boolean result = false;
			for (int i=0; i<30 && !result; i++) {
				if (i != 0) Output.println("Didn't find someone to fight. Will try again.");
				result = this.completeFight(ins);
			}
			if (!result) Output.println("Will abort fighting. (Didn't find an opponent.)");
		} catch (NoList l) {
			Output.error("Will abort fighting. (No list avalible.)");
		}
	}
	
	
	/**
	 * Try to find an opponent and attack him. 
	 * 
	 * @param current instance
	 * @return false if nobody was attack
	 * @throws NoList if no list is avalible
	 * @throws IOException
	 */
	private final boolean completeFight(Instance ins) throws NoList, IOException { 
		ins.visit("http://www.bundeskampf.com/fights/start");
		
		// search a opponent on the "high money" list
		Opponent opp = this.findHighMoney();
		if (opp != null) {
			try {
				int money = ins.fight(opp.attack, opp.name);
				
				// Fight was won, we safe the opponent
				if (money > ins.getMoneyFightAgain()) {
					// save
					opp.fightsToday++;
				
				// Fight was lost
				} else if (money == -1) {
					// remove from list
					PlanAngriff.highMoney.remove(opp);
					
					// add to bad list
					Output.noteln("Add "+opp.name + " to \"bad opponent\" list");
					PlanAngriff.bad.add(opp);
					
				// Fight was won, but with low money
				} else {
					PlanAngriff.highMoney.remove(opp);
				}
				return true;
			} catch (BadOpponent e) {
				// remove from list
				PlanAngriff.highMoney.remove(opp);
				// add to bad list
				Output.noteln("Add "+opp.name + " to \"bad opponent\" list");
				PlanAngriff.bad.add(opp);
				return false;
			}
		}
		
		try {
			int level = this.level + ins.user.getLevel();
			JSONArray arr = this.getList(ins, level);
			JSONObject now;
			
			// If list is avalible
			if (arr.length() > 0) {
				for (int i=0; i<arr.length(); i++) {
					now = arr.getJSONObject(i);
					
					boolean guild;
					try {
						now.getInt("guild");
						guild = false;
					} catch (JSONException e) {
						guild = true;
					}
					
					if (now.getInt("level") == level
						&& !now.getString("race").equalsIgnoreCase(ins.user.getRace())
						&& !now.getString("race").equalsIgnoreCase(ins.user.getRace2())
						&& (	this.club.equals(Club.Whatever) || 
								(guild && this.club.equals(Club.Yes)) ||
								(!guild && this.club.equals(Club.No)))
						&& !this.badOpponent(now.getString("attack"))
						) {
						try {
							int result = ins.fight(now.getString("attack"), now.getString("name"));
							
							// Fight was won, we safe the opponent
							if (result > ins.getMoneyFightAgain()) {
								// save
								this.addHighMoney(now.getString("attack"), now.getString("name"));
							
							// Fight was lost
							} else if (result == -1) {
								// save, here we don't need the name
								this.addLowMoney(now.getString("attack"), now.getString("name"));
							} else {
								// save, here we don't need the name
								this.addLowMoney(now.getString("attack"), now.getString("name"));
							}
						} catch (BadOpponent e) {
							Output.noteln("Add "+now.getString("name") + " to \"bad opponent\" list");
							PlanAngriff.bad.add(new Opponent(now.getString("attack"), now.getString("name")));
						}
						
						return true;
					}
				}
				
				
			} else {
				throw new NoList();
			}
		} catch (JSONException e){
		}
		return false;
	}

	public final static void showLists() {

		if (PlanAngriff.bad.size() > 0) {
			Output.noteln("---- bad list ----");
			for (Opponent o : PlanAngriff.bad) {
				Output.noteln(o.name);
			}
		}
		if (PlanAngriff.highMoney.size() > 0) {
			Output.noteln("---- high money ----");
			for (Opponent o : PlanAngriff.bad) {
				Output.noteln(o.name + "\t"+o.fightsToday);
			}
		}
		if (PlanAngriff.lowMoneyPointer > 0) {
			Output.noteln("---- low money ----");
			for (int i=0; i<PlanAngriff.lowMoney.length; i++) {
				if (PlanAngriff.lowMoneyPointer == i && PlanAngriff.lowMoney[i] == null) {
					break;
				}
				if (PlanAngriff.lowMoneyPointer == i) Output.note(" -> ");
				Output.noteln(PlanAngriff.lowMoney[i].name);
			}
		}
	}
	
	/**
	 * find a opponent from the "high money" list, which can fight
	 * 
	 * @return null if nobody found or the opponent
	 */
	private final Opponent findHighMoney() {
		this.checkDateCounter();
		
		for (Opponent opp : PlanAngriff.highMoney) {
			if (opp.canFight()) {
				return opp;
			}
		}

		return null;
	}

	
	/**
	 * Reset the counter if started a new day
	 */
	private final void checkDateCounter() {
		Calendar today = new GregorianCalendar();
		today.set(
			Calendar.YEAR,
			Calendar.MONTH,
			Calendar.DAY_OF_YEAR,
			0,
			0);
		
		if (PlanAngriff.countDate.before(today)) {
			PlanAngriff.countDate = new GregorianCalendar();
				
			// Set all counters to zero
			for (Opponent opp : PlanAngriff.highMoney) {
				opp.fightsToday = 0;
			}
				
			PlanAngriff.bad = new ArrayList<Opponent>();
		}
	}
	
	
	/**
	 * Returns true if the opponent is on the "low money" list or 
	 * if the opponent is on the "max fight" list.
	 * 
	 * @param attack
	 * @return true if on the list
	 */
	private final boolean badOpponent(String attack) {
		for (int i=0; i<PlanAngriff.lowMoney.length; i++) {
			if (PlanAngriff.lowMoneyPointer == i && PlanAngriff.lowMoney[i] == null) {
				break;
			}
			if (PlanAngriff.lowMoney[i].attack.equals(attack)) {
				return true;
			}
		}
		
		for (Opponent o : PlanAngriff.bad) {
			if (o.attack == attack) {
				return true;
			}
		}
		
		return false;
	}

	
	/**
	 * Try to get the list of opponents for the given level.
	 * 
	 * Reads club from the config.
	 * 
	 * @param current instance
	 * @param level
	 * @return the list of opponents as JSON
	 * @throws NoList
	 */
	private final JSONArray getList(Instance i, int level) throws NoList {
		Output.noteln("Get opponent list");
		try {
			HttpResponse response;
			
			// send post 
			HttpPost http = new HttpPost("http://www.bundeskampf.com/fights/opponentsListJson");
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("selectRace", "0"));
			nvps.add(new BasicNameValuePair("selectLevel", String.valueOf(level)));
			
			http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			// Create a response handler
			response = i.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();
			JSONArray arr;

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
				arr = ob.getJSONArray("list");
				resEntity.consumeContent();
			} else {
				arr = new JSONArray();
			}
			return arr;

		} catch (JSONException e) {
			Output.println("No list avalible");
			Output.error(e);
		} catch (Exception e) {
			Output.error(e);
			Output.println("No list avalible");
		}
		throw new NoList();
	}
	
	
	/**
	 * We have to initiate this class.
	 */
	public final static void initiate() {
		PlanAngriff.countDate = new GregorianCalendar();
		
		PlanAngriff.lowMoney = new Opponent[100];
		PlanAngriff.lowMoneyPointer = 0;
		
		PlanAngriff.highMoney = new ArrayList<Opponent>();
		PlanAngriff.bad = new ArrayList<Opponent>();
	}
	
	
	/**
	 * Add an opponent to the "low money" list
	 * 
	 * @param attack
	 */
	private final void addLowMoney(String attack, String name) {
		Output.noteln("Add to \"low money\" list");
		
		PlanAngriff.lowMoney[PlanAngriff.lowMoneyPointer] = new Opponent(attack, name);
		PlanAngriff.lowMoneyPointer++;
		
		if (PlanAngriff.lowMoneyPointer == PlanAngriff.lowMoney.length) {
			PlanAngriff.lowMoneyPointer = 0;
		}
	}
	
	
	/**
	 * Add an opponent to the "high money" list
	 * 
	 * @param attack
	 * @param name
	 */
	private final void addHighMoney(String attack, String name) {
		Output.noteln("Add "+name+ " to \"high money\" list");
		
		// is inside?
		boolean inside = false;
		for (Opponent a : PlanAngriff.highMoney) {
			if (a.attack.equals(attack)) {
				inside = true;
				a.fightsToday++;
				break;
			}
		}
		
		if (inside) return;
		
		PlanAngriff.highMoney.add(new Opponent(attack, name));
	}
	
	
	private final class NoList extends Exception {
		private static final long serialVersionUID = -2317742009841698364L;
	}
	
	
	private final class Opponent {
		public final String attack;
		public final String name;
		public int fightsToday = 0;
		
		public Opponent (String attack, String name) {
			this.attack = attack;
			this.name = name;
		}
		
		public final boolean canFight() {
			return (this.fightsToday < Control.maxFights);
		}
	}
}
