package plan;

import java.io.IOException;

import control.BadOpponent;
import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public final class PlanKampf extends PlanObject {
	private final String idOrName;

	public PlanKampf(JSONObject object) throws FatalError {
		this.setName("Kampf");
		
		try {
			this.idOrName = object.getString("Kampf");
		} catch (JSONException e) {
			throw new FatalError("Config error: Kampf config is bad");
		}
	}
	
	public final void run() throws IOException {
		Instance ins = Control.current;
		Output.println("-> Kampf (" + this.idOrName +")");
		
		String attack = ins.findAttackById(this.idOrName);
		if (attack == null) {
			attack = ins.findAttackByName(this.idOrName);
		}
		
		if (attack == null) {
			Output.println("Can't find. Will abort.");
			return;
		}
		
		
		try {
			ins.fight(attack, this.idOrName);
		} catch (BadOpponent o) {
			Output.error("Will abort fighting. (To many fights today)");
		}
	}
}
