package plan;

import java.io.IOException;
import control.RestartLater;
import output.FatalError;
import output.InfoFile;
import output.Output;
import json.JSONException;
import json.JSONObject;

public final class PlanBefehl extends PlanObject {
	public PlanBefehl(JSONObject object) throws FatalError {
		this.setName("Befehl");
		
		try {
			object.getBoolean("Befehl");
			
		} catch (JSONException e) {
			throw new FatalError("Config error: Befehl have to be true");
		}
	}
	
	public final void run() throws IOException, FatalError, JSONException, RestartLater {
		Output.print("-> Befehl");
		
		JSONObject now = InfoFile.getBefehl();
		while (now != null) {
			Output.println(" (get one)");
			PlanObject doit = new PlanObject();
			doit = PlanObject.get(now);
			doit.run();
			now = InfoFile.getBefehl();
			Output.print("-> Befehl");
		}
		Output.println(" (nothing)");
	}
}
