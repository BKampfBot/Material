package plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.BadOpponent;
import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanAngriff extends PlanObject {
	public enum Club { No, Yes, Whatever };
	
	/**
	 * Vereinszugehörigkeit
	 * 		No
	 * 		Yes
	 * 		Whatever
	 */
	private Club club;
	
	/**
	 * Levelunterschied
	 */
	private int level;
	
	/**
	 * Maximaler Respekt
	 */
	private int hp = -1;
	
	/**
	 * Soll auf Freunde überprüft werden?
	 */
	private boolean friend = false;

	private static Opponent[] lowMoney;
	private static int lowMoneyPointer;
	
	private static ArrayList<Opponent> highMoney;
	private static ArrayList<Opponent> bad;
	
	private static Calendar countDate;

	public PlanAngriff(JSONObject object) throws FatalError {
		this.setName("Angriff");
		
		try {
			// {"Angriff":{"Verein":1,"Stufe":1,"Respekt":1000000}}
			JSONObject angriff = object.getJSONObject("Angriff");
			
			int c = angriff.getInt("Verein");
			if (c == 0) this.club = Club.Whatever;
			else if (c == 1) this.club = Club.Yes;
			else if (c == -1) this.club = Club.No;
			else new FatalError("Config error: Verein have to be 1,-1 or 0");
			
			this.level = angriff.getInt("Stufe");
			
			// Attribute havn't set
			try {
				this.hp = angriff.getInt("Respekt");
			} catch (JSONException r) {}
			try {
				this.friend = angriff.getBoolean("Freunde");
			} catch (JSONException r) {}
			
		} catch (JSONException e) {
			throw new FatalError("Config error: Angriff config is bad");
		}
	}
	
	public final void run() throws IOException {
		Instance ins = Control.current;
		Output.println(
				"-> Angriff (Verein: " +
				(this.club.equals(Club.Yes)? "Ja":"") +
				(this.club.equals(Club.No)? "Nein":"") +
				(this.club.equals(Club.Whatever)? "Egal":"") +
				", Level: " +
				String.valueOf(this.level + ins.user.getLevel()) +
				")");

		if (this.hp > 0) Output.noteln("Maximaler Respekt: "+this.hp);
		
		if (!PlanAngriff.available(15)) {
			return;
		}
		
		try {
			boolean result = false;
			for (int i=0; i<30 && !result; i++) {
				if (i != 0) Output.println("Didn't find someone to fight. Will try again.");
				result = this.completeFight(ins);
			}
			if (!result) Output.println("Will abort fighting. (Didn't find an opponent.)");
		} catch (NoList l) {
			Output.error("Will abort fighting. (No list avalible.)");
		}
	}
	
	public final static boolean available(int retry) throws IOException {
		
		for (int i=retry; i>0; i--) {
			if (i!=retry) {
				try { Thread.sleep(60000); } catch (InterruptedException es) {}
				Output.println(" - retry");
			}
			
			// HTTP parameters stores header etc.
			HttpParams params = new BasicHttpParams();
			params.setParameter("http.protocol.handle-redirects",false);
	
	
			HttpGet httpget = new HttpGet("http://www.bundeskampf.com/fights/start");
			httpget.setParams(params);
			
			HttpResponse response = Control.current.httpclient.execute(httpget);
	
			// obtain redirect target
			Header locationHeader = response.getFirstHeader("location");
			HttpEntity resEntity = response.getEntity();
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			if (locationHeader == null) {
				return true;
			}
			Output.print("Fighting not available");
		}
		Output.println(" - abort");
		return false;
	}
	
	
	/**
	 * Try to find an opponent and attack him. 
	 * 
	 * @param current instance
	 * @return false if nobody was attack
	 * @throws NoList if no list is avalible
	 * @throws IOException
	 */
	private final boolean completeFight(Instance ins) throws NoList, IOException { 
		ins.visit("http://www.bundeskampf.com/fights/start");
		
		/*
		 * {
		 * 	"myid":"565504",
		 * 	"myname":"ultratest",
		 * 	"mylevel":"3",
		 * 	"myraceid":"2",
		 * 	"powercrystals":"12",
		 * 	"opponent":{
		 * 		"id":"166309",
		 * 		"signup_id":"166309",
		 * 		"guild_id":"12601",
		 * 		"race_id":"8",
		 * 		"title_id":"13",
		 * 		"name":"mika2009",
		 * 		"pic":"8.png",
		 * 		"gender":"m",
		 * 		"level":"24",
		 * 		"gold":"1209",
		 * 		"bank_gold":"0",
		 * 		"stone":"42",
		 * 		"ep":"85",
		 * 		"lp":10848,
		 * 		"max_lp":"47",
		 * 		"lp_full_ts":"1300138414",
		 * 		"no_fight_until":"1300138834",
		 * 		"hp":"514114",
		 * 		"guild_hp":"34917",
		 * 		"guild_search":"0",
		 * 		"powercrystals":"401",
		 * 		"fortunes":"40843",
		 * 		"tactic":"O:8:\"stdClass\":2:{s:6:\"defens\";a:3:{i:0;s:8:\"legright\";i:1;s:4:\"body\";i:2;s:7:\"legleft\";}s:6:\"attack\";a:3:{i:0;s:7:\"legleft\";i:1;s:4:\"head\";i:2;s:8:\"legright\";}}",
		 * 		"strength":"846",
		 * 		"intelligence":"528",
		 * 		"skill":"990",
		 * 		"endurance":"1370",
		 * 		"cognition":"344",
		 * 		"level_attrs":"0",
		 * 		"ride_id":"2",
		 * 		"ride_speed":"0",
		 * 		"ride_weapon":"0",
		 * 		"ride_shield":"0",
		 * 		"description":"Ich war bisher zu faul eine Beschreibung einzugeben, hole ich aber sicher bald nach!",
		 * 		"textBefore":null,
		 * 		"textAfter":null,
		 * 		"busy":"no",
		 * 		"nb":"0",
		 * 		"item_page_id":"19746",
		 * 		"item_page_ids_done":"1854",
		 * 		"arena_bonus":"180",
		 * 		"ep_bonus":"0",
		 * 		"plating_bonus":"42",
		 * 		"standing_bonus":"21",
		 * 		"quest_gold_bonus":"6",
		 * 		"lost_gold_bonus":"6",
		 * 		"won_gold_bonus":"24",
		 * 		"quest_time_bonus":"20",
		 * 		"s_rcv_fight_mail":"no",
		 * 		"s_quest_music":"no",
		 * 		"challenge_profil":"no",
		 * 		"fightsession":null,
		 * 		"series_current":"4531",
		 * 		"series_max":"5142",
		 * 		"safepoint":"4501",
		 * 		"easterspecial":"0",
		 * 		"status":"0",
		 * 		"news":"0",
		 * 		"modified":"2011-03-14 22:29:46",
		 * 		"created":"2009-12-11 08:59:08",
		 * 		"allAttrs":{
		 * 			"strength":924,
		 * 			"intelligence":586,
		 * 			"skill":1224,
		 * 			"endurance":1575,
		 * 			"cognition":344,
		 * 			"block":"35",
		 * 			"sneaky":16,
		 * 			"_weaponDamage":{
		 * 				"from":"23",
		 * 				"to":"32",
		 * 				"range_damage":"30"
		 * 			},
		 * 			"fightDamage":{
		 * 				"from":385,
		 * 				"to":536
		 * 			},
		 * 			"magicDamage":887,
		 * 			"rangeWeaponDamage":"30",
		 * 			"hitChance":1234,
		 * 			"enthusiasm":737,
		 * 			"maxLifeEnergy":10850,
		 * 			"lpPro":62,
		 * 			"plating":792,
		 * 			"platingBonus":234
		 * 		},
		 * 		"TrainingStats":{
		 * 			"2":{"id":"8","class":"2","points":"20"}
		 * 		},
		 * 		"t_name":"p2",
		 * 		"doSneakyAt":93,
		 * 		"race_name":"Meck.-Vorp."
		 * 	},
		 * 	"results":{
		 * 		"p1":{
		 * 			"magicDamage":2,
		 * 			"_weaponDamage":{"from":"1","to":"3"},
		 * 			"fightDamage":{"from":1,"to":3},
		 * 			"hits":0,
		 * 			"criticalHits":0,
		 * 			"blocked":0,
		 * 			"platting":2,
		 * 			"timeToFullLP":0,
		 * 			"lp":0,
		 * 			"maxLp":61,
		 * 			"gold":0,
		 * 			"hp":0,
		 * 			"series_current":0,
		 * 			"series_max":"1",
		 * 			"PlaceOfHonour":{"before":140955,"after":140955}
		 * 		},
		 * 		"p2":{
		 * 			"magicDamage":917,
		 * 			"fightDamage":{"from":385,"to":536},
		 * 			"hits":0,
		 * 			"criticalHits":0,
		 * 			"blocked":0,
		 * 			"platting":792,
		 * 			"lp":10848,
		 * 			"maxLp":10850,
		 * 			"gold":0,
		 * 			"hp":0,
		 * 			"series_current":"4531",
		 * 			"series_max":"5142",
		 * 			"PlaceOfHonour":{"before":780,"after":780}
		 *		},
		 *		"fightWasWon":false,
		 *		"log":[[1,"spellhit",2,null,null,null,null,null,null,1050,null,null],[2,"spellhit",917,null,null,null,null,null,null,1050,null,null],[2,"win",null]]},
		 *		"myracename":"Bayern",
		 *		"noFight":1,
		 *		"aTime":{"toYear":"2011","toMonth":"03","toDay":"14","toHour":"23","toMinute":"00","toSecond":"13"},
		 *		"p1Sneak":0,
		 *		"p2Sneak":0
		 *		}
		 */
		
		// search a opponent on the "high money" list
		Opponent opp = this.findHighMoney();
		if (opp != null) {
			try {
				int money = ins.fight(opp.attack, opp.name, "Angriff High");
				
				// Fight was won, we safe the opponent
				if (money > ins.getMoneyFightAgain()) {
					// save
					opp.fightsToday++;
				
				// Fight was lost
				} else if (money == -1) {
					// remove from list
					PlanAngriff.highMoney.remove(opp);
					
					// add to bad list
					Output.noteln("Add "+opp.name + " to \"bad opponent\" list");
					PlanAngriff.bad.add(opp);
					
				// Fight was won, but with low money
				} else {
					PlanAngriff.highMoney.remove(opp);
					this.addLowMoney(opp.attack, opp.name);
				}
				return true;
			} catch (BadOpponent e) {
				// remove from list
				PlanAngriff.highMoney.remove(opp);
				// add to bad list
				Output.noteln("Add "+opp.name + " to \"bad opponent\" list");
				PlanAngriff.bad.add(opp);
				return false;
			}
		}
		
		// Falls wir nach Freunden suchen sollen, machen wir das vorher
		String friends[] = new String[0];
		if (this.friend) {
			friends = this.getFriendList();
		}
		
		try {
			int level = this.level + ins.user.getLevel();
			JSONArray arr = this.getList(ins, level);
			JSONObject now;
			
			for (int a=0; a<3; a++) {
				// If list is avalible
				if (arr.length() > 0) {
					for (int i=0; i<arr.length(); i++) {
						now = arr.getJSONObject(i);
						
						boolean guild;
						try {
							now.getInt("guild");
							guild = false;
						} catch (JSONException e) {
							guild = true;
						}
						
						if (now.getInt("level") == level
							&& !now.getString("race").equalsIgnoreCase(ins.user.getRace())
							&& !now.getString("race").equalsIgnoreCase(ins.user.getRace2())
							&& (	this.club.equals(Club.Whatever) || 
									(guild && this.club.equals(Club.Yes)) ||
									(!guild && this.club.equals(Club.No)))
							&& !this.badOpponent(now.getString("attack"))
							&& (	this.hp <= 0 || Integer.valueOf(now.getString("hp")) < this.hp)
							&& !this.isFriend(friends, now.getString("name"))
						) {
							try {
								int result = ins.fight(now.getString("attack"), now.getString("name"), "Angriff");								
								// Fight was won, we safe the opponent
								if (result > ins.getMoneyFightAgain()) {
									// save
									this.addHighMoney(now.getString("attack"), now.getString("name"));
								
								// Fight was lost
								} else if (result == -1) {
									// save, here we don't need the name
									this.addLowMoney(now.getString("attack"), now.getString("name"));
								} else {
									// save, here we don't need the name
									this.addLowMoney(now.getString("attack"), now.getString("name"));
								}
							} catch (BadOpponent e) {
								Output.noteln("Add "+now.getString("name") + " to \"bad opponent\" list");
								PlanAngriff.bad.add(new Opponent(now.getString("attack"), now.getString("name")));
							}
							
							return true;
						}
					}
				} else {
					throw new NoList();
				}
				
				// we get a new list in 1 second
				try { Thread.sleep(1000); } catch (InterruptedException e) {}
				arr = this.getList(ins, level);
			}
		} catch (JSONException e){
		}
		return false;
	}
	
	/**
	 * Überprüft ob ein Gegner auf der Liste ist
	 * @param list
	 * @param name
	 * @return boolean
	 */
	private final boolean isFriend(String[] list, String name) {
		for(int i=0; i<list.length; i++) {
			if (list[0].equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}

	public final static void showLists() {

		if (PlanAngriff.bad.size() > 0) {
			Output.noteln("---- bad list ----");
			for (Opponent o : PlanAngriff.bad) {
				Output.noteln(o.name);
			}
		}
		if (PlanAngriff.highMoney.size() > 0) {
			Output.noteln("---- high money ----");
			for (Opponent o : PlanAngriff.highMoney) {
				Output.noteln(o.name + "\t"+o.fightsToday);
			}
		}
		if (PlanAngriff.lowMoneyPointer > 0) {
			Output.noteln("---- low money ----");
			int i;
			for (i=0; i<PlanAngriff.lowMoney.length; i++) {
				if (PlanAngriff.lowMoneyPointer == i && PlanAngriff.lowMoney[i] == null) {
					
					break;
				}
				if (PlanAngriff.lowMoneyPointer == i) Output.note(" -> ");
				Output.note(PlanAngriff.lowMoney[i].name + " ");
			}
			Output.noteln("\ntotal: "+i);
		}
	}
	
	/**
	 * find a opponent from the "high money" list, which can fight
	 * 
	 * @return null if nobody found or the opponent
	 */
	private final Opponent findHighMoney() {
		this.checkDateCounter();
		
		for (Opponent opp : PlanAngriff.highMoney) {
			if (opp.canFight()) {
				return opp;
			}
		}

		return null;
	}

	
	/**
	 * Reset the counter if started a new day
	 */
	private final void checkDateCounter() {
		Calendar today = new GregorianCalendar();
		today.set(Calendar.HOUR, 0);
		today.set(Calendar.MINUTE, 0);
		
		if (PlanAngriff.countDate.before(today)) {
			PlanAngriff.countDate = new GregorianCalendar();
				
			// Set all counters to zero
			for (Opponent opp : PlanAngriff.highMoney) {
				opp.fightsToday = 0;
			}
				
			PlanAngriff.bad = new ArrayList<Opponent>();
		}
	}
	
	
	/**
	 * Returns true if the opponent is on the "low money" list or 
	 * if the opponent is on the "max fight" list.
	 * 
	 * @param attack
	 * @return true if on the list
	 */
	private final boolean badOpponent(String attack) {
		for (int i=0; i<PlanAngriff.lowMoney.length; i++) {
			if (PlanAngriff.lowMoneyPointer == i && PlanAngriff.lowMoney[i] == null) {
				break;
			}
			if (PlanAngriff.lowMoney[i].attack.equals(attack)) {
				return true;
			}
		}
		
		for (Opponent o : PlanAngriff.bad) {
			if (o.attack == attack) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * List die Freundesliste aus und gibt sie als String-Array zurück.
	 * 
	 * @return String[]
	 */
	private final String[] getFriendList() {
		//{"list":[{"profil":"","msg":"","id":"","signup_id":"","level":"","race":"","name":"","hp":"","online":""}],"nexturl":null,"prevurl":null}
		Output.noteln("Get friend list");
		try {
			
			HttpGet http = new HttpGet("http://www.bundeskampf.com/characters/friendsListJson");
			
			// Create a response handler
			HttpResponse response = Control.current.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();
			
			JSONObject ob = new JSONObject(new JSONTokener(EntityUtils.toString(resEntity)));
			JSONArray arr = ob.getJSONArray("list");
			
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			
			String[] list = new String[arr.length()];
			for(int i=0; i<arr.length(); i++) {
				JSONObject now = arr.getJSONObject(i);
				list[i] = now.getString("name");
			}
			return list;
		} catch (Exception e) {
			return new String[0];
		}
	}
	
	/**
	 * Try to get the list of opponents for the given level.
	 * 
	 * Reads club from the config.
	 * 
	 * @param current instance
	 * @param level
	 * @return the list of opponents as JSON
	 * @throws NoList
	 */
	private final JSONArray getList(Instance i, int level) throws NoList {
		Output.noteln("Get opponent list");
		try {
			HttpResponse response;
			
			// send post 
			HttpPost http = new HttpPost("http://www.bundeskampf.com/fights/opponentsListJson");
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("selectRace", "0"));
			nvps.add(new BasicNameValuePair("selectLevel", String.valueOf(level)));
			
			http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			// Create a response handler
			response = i.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();
			JSONArray arr;

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
				arr = ob.getJSONArray("list");
				resEntity.consumeContent();
			} else {
				arr = new JSONArray();
			}
			return arr;

		} catch (JSONException e) {
			Output.println("No list avalible");
			Output.error(e);
		} catch (Exception e) {
			Output.error(e);
			Output.println("No list avalible");
		}
		throw new NoList();
		
		/**
		 * {"list":[
{
	"attack":"\/fights\/start\/53599",
	"profil":"\/characters\/profile\/EDGLM",
	"id":"53599",
	"signup_id":"53599",
	"race":"Nordrhein-Westfalen",
	"level":"2",
	"enemy":0,
	"friend":0,
	"guild":0,
	"name":"LaLa26",
	"hp":"82"},[...]],
		 */
	}
	
	
	/**
	 * We have to initiate this class.
	 */
	public final static void initiate() {
		PlanAngriff.countDate = new GregorianCalendar();
		
		PlanAngriff.lowMoney = new Opponent[100];
		PlanAngriff.lowMoneyPointer = 0;
		
		PlanAngriff.highMoney = new ArrayList<Opponent>();
		PlanAngriff.bad = new ArrayList<Opponent>();
	}
	
	
	/**
	 * Add an opponent to the "low money" list
	 * 
	 * @param attack
	 */
	private final void addLowMoney(String attack, String name) {
		Output.noteln("Add to \"low money\" list");
		
		PlanAngriff.lowMoney[PlanAngriff.lowMoneyPointer] = new Opponent(attack, name);
		PlanAngriff.lowMoneyPointer++;
		
		if (PlanAngriff.lowMoneyPointer == PlanAngriff.lowMoney.length) {
			PlanAngriff.lowMoneyPointer = 0;
		}
	}
	
	
	/**
	 * Add an opponent to the "high money" list
	 * 
	 * @param attack
	 * @param name
	 */
	private final void addHighMoney(String attack, String name) {
		Output.noteln("Add "+name+ " to \"high money\" list");
		
		// is inside?
		boolean inside = false;
		for (Opponent a : PlanAngriff.highMoney) {
			if (a.attack.equals(attack)) {
				inside = true;
				a.fightsToday++;
				break;
			}
		}
		
		if (inside) return;
		
		PlanAngriff.highMoney.add(new Opponent(attack, name));
	}
	
	
	private final class NoList extends Exception {
		private static final long serialVersionUID = -2317742009841698364L;
	}
	
	
	private final class Opponent {
		public final String attack;
		public final String name;
		public int fightsToday = 1;
		
		public Opponent (String attack, String name) {
			this.attack = attack;
			this.name = name;
		}
		
		public final boolean canFight() {
			return (this.fightsToday < Control.maxFights);
		}
	}
}
