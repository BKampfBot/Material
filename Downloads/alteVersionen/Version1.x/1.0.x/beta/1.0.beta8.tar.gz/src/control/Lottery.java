package control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import output.Output;

public final class Lottery {
	public static int[] numbers = new int[5];
	
	public Lottery(Instance ins, boolean random) {
		
		if (random) {
			Random generator = new Random();
			
			int n[] = {-1, -1, -1, -1, -1};
			
			for (int i=0; i<5; i++) {
				int now = generator.nextInt(49);
				while (n[0]==now || n[1]==now || n[2]==now || n[3]==now || n[4]==now) {
					now = generator.nextInt(49);
				}
				Lottery.numbers[i] = now+1;
				
				n[i] = now;
			}
		}

		Arrays.sort(Lottery.numbers);
		
		ins.visit("http://www.bundeskampf.com/lotto/history");
		
		HttpEntity entity = ins.get("http://www.bundeskampf.com/lotto/schein");
		if (entity != null) {
			try {
				String s = EntityUtils.toString(entity);

				int start = s.indexOf("/img/flash/ankreuzen.swf");
				if (start == -1) throw new NotPossible();
				start -= 80;
		
				s = s.substring(start);
				
				int lineFront = s.indexOf('{');
				int lineEnd = s.indexOf('}', lineFront+1);
				s = s.substring(lineFront, lineEnd+1);
				//Output.noteln(s);
				/*{
               quelle: "/img/flash/ankreuzen.swf",
               minpoints: "300",
               currentpoints: "136",
               jackpot: "132908",
               numbers: "",               
               ticketid: "0",
               STAGE_WIDTH: "708",
               STAGE_HEIGHT: "569"
            }*/
				JSONObject lottery = new JSONObject(new JSONTokener(s));
				
				int minPoints = Integer.parseInt(lottery.getString("minpoints"));
				int currentPoints = Integer.parseInt(lottery.getString("currentpoints"));
				
				if (minPoints > currentPoints) {
					throw new NotPossible("Not enough points");
				}
				
				if (!lottery.getString("numbers").equals("")) {
					throw new NotPossible("You already gived numbers");
				}
				
				// Send numbers

				HttpPost httppost = new HttpPost("http://www.bundeskampf.com/lotto/schein");
					
				List <NameValuePair> nvps = new ArrayList <NameValuePair>();
				
				String numbers= "";
				for (int i=0; i<5; i++) {
					numbers += Lottery.numbers[i];
					if (i != 4) numbers += ",";
				}
				
				nvps.add(new BasicNameValuePair("numbers", numbers));
				httppost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
				
				// send post
				HttpResponse response = ins.httpclient.execute(httppost);
				entity = response.getEntity();
				
				if (entity != null) {
					entity.consumeContent();
					Output.println("Added numbers: "+numbers);
				}
			} catch (Exception e) {
				Output.println(e.getMessage());
			}
		}
	}
		
	private final class NotPossible extends Exception {
		public NotPossible(String string) {
			super(string);
		}

		public NotPossible() {
			super();
		}

		private static final long serialVersionUID = 201102060111L;
		
	}
}
