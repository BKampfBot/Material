package output;

import control.Control;

public class Output {

	public static void error(String string) {
		System.err.print(string + "\n");
	}

	public static void print(String string) {
		if (Control.current != null && Control.current.getOutput()>=1)
			System.out.print(string);
	}
	
	public static void println(String string) {
		Output.print(string+"\n");
	}
	
	public static void note(String string) {
		if (Control.current != null && Control.current.getOutput()>=2)
			System.out.print(string);
	}
	
	public static void noteln(String string) {
		Output.note(string + "\n");
	}

	public static void help() {
		System.out.print(
			"Bundeskampf-Bot - Version: " + Control.version + "\n" +
			"\n" +
			"Aufruf: Bundeskampf.jar [Optionen]\n" +
			"        Bundeskampf.jar [Optionen] quiz\n" +
			"        Bundeskampf.jar [Optionen] los\n" +
			"\n" +
			"Optionen:\n" +
			"  --help  -h     Zeigt diese Hilfe an\n" +
			"  --config=FILE  Nimmt FILE als Konfiguration\n" +
			"\n" +
			"Weitere Hinweise auf http://www.georf.de/bundeskampf\n");
		System.exit(0);
	}

	public static void error(Exception e) {
		String message = "An error occured:\n" + e.getMessage() + "\n";
		StackTraceElement[] trace = e.getStackTrace();
		for (StackTraceElement elem:trace) {
			message += elem.toString() + "\n";
		}
		Output.error(message + "\n\n");
	}
}
