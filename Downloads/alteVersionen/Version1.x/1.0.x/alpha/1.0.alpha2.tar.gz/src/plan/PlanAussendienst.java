package plan;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public class PlanAussendienst extends PlanObject {
	private int difficult;

	public PlanAussendienst(JSONObject object) throws FatalError {
		this.setName("Außendienst");
		
		try {
			this.difficult = object.getInt("Außendienst");
		} catch (JSONException e) {
			throw new FatalError("Config error: Außendienst have to be 0 or 1");
		}
		
		if (this.difficult > 1) {
			Output.error("Config: Außendienst is set to 1.");
			this.difficult = 1;
		} else if (this.difficult < 0) {
			Output.error("Config: Außendienst is set to 0.");
			this.difficult = 0;
		}
	}
	
	// TODO
	public void run() {
		
	}

}
