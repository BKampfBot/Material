package plan;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public class PlanBoese extends PlanObject {
	private int straight;

	public PlanBoese(JSONObject object) throws FatalError {
		this.setName("Böse");
		
		try {
			this.straight = object.getInt("Böse");
		} catch (JSONException e) {
			throw new FatalError("Config error: Böse have to be 0 or 1");
		}
		
		if (this.straight > 1) {
			Output.error("Config: Böse is set to 1.");
			this.straight = 1;
		} else if (this.straight < 0) {
			Output.error("Config: Böse is set to 0.");
			this.straight = 0;
		}
	}
}
