package output;

public final class FatalError extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 201102020008L;
	
	public FatalError (String message) {
		super(message);
	}
}
