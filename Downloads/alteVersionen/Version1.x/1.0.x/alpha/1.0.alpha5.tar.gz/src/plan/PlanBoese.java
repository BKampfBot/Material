package plan;

import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

import control.BadOpponent;
import control.Control;
import control.Instance;
import output.FatalError;
import output.Output;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanBoese extends PlanObject {
	private int straight;
	private static HashMap<Integer, Opponent> list;

	public PlanBoese(JSONObject object) throws FatalError {
		this.setName("Böse");
		
		if (PlanBoese.list == null) {
			PlanBoese.list = new HashMap<Integer, Opponent>(25, 0.8f);
		}
		
		try {
			this.straight = object.getInt("Böse");
		} catch (JSONException e) {
			throw new FatalError("Config error: Böse have to be 0 or 1");
		}
		
		if (this.straight > 1) {
			Output.error("Config: Böse is set to 1.");
			this.straight = 1;
		} else if (this.straight < 0) {
			Output.error("Config: Böse is set to 0.");
			this.straight = 0;
		}
		//GET /fights/enemysListJson HTTP/1.1

		// {"list":[{"attack":"\/fights\/start\/100249","profil":"\/characters\/profile\/AABEHN","id":"100249","signup_id":"100249","race":"Meck.-Vorp.","name":"hali","level":"29","hp":"614816"}],"nexturl":null,"prevurl":null}
		// {"list":[{"attack":"\/fights\/start\/163988","profil":"\/characters\/profile\/AGELLM","id":"163988","signup_id":"163988","race":"Meck.-Vorp.","name":"alfMeier","level":"20","hp":"388186"},{"attack":"\/fights\/start\/149359","profil":"\/characters\/profile\/AEKFIN","id":"149359","signup_id":"149359","race":"Meck.-Vorp.","name":"!!!!!Stampras!!","level":"21","hp":"429425"},{"attack":"\/fights\/start\/100249","profil":"\/characters\/profile\/AABEHN","id":"100249","signup_id":"100249","race":"Meck.-Vorp.","name":"hali","level":"29","hp":"614873"}],"nexturl":null,"prevurl":null}
	}

	
	public final void run() throws IOException {
		Instance ins = Control.current;
		
		Output.print("-> Böse (");
		if (this.straight == 1) Output.print("Zufall");
		else Output.print("nach Liste");
		Output.println(")");
		
		try {
			boolean result = false;
			for (int i=0; i<3 && !result; i++) {
				if (i != 0) Output.println("Didn't find someone to fight. Will try again.");
				result = this.completeFight(ins);
			}
			if (!result) Output.println("Will abort fighting. (Didn't find an opponent.)");
		} catch (NoList l) {
			Output.error("Will abort fighting. (No list avalible.)");
		} catch (BadOpponent o) {
			Output.error("Will abort fighting. (Didn't find an opponent with good status.)");
		}
	}
	
	
	private final boolean completeFight(Instance ins) throws NoList, BadOpponent, IOException { 
		ins.visit("http://www.bundeskampf.com/fights/start");
		
		try {
			
			JSONArray arr = this.getList(ins);
			JSONObject now;
			
			// If list is avalible
			if (arr.length() > 0) {
				for (int i=0; i<arr.length(); i++) {
					now = arr.getJSONObject(i);
					
					// in list => check date
					if (PlanBoese.list.containsKey(Integer.parseInt(now.getString("id")))) {
						PlanBoese.list.get(Integer.parseInt(now.getString("id"))).checkFightCounts();
					
					// not in list => add
					} else {
						Output.noteln("Add " + now.getString("name") + " to enemy list");
						PlanBoese.list.put(
							Integer.parseInt(now.getString("id")), 
							new Opponent(
									now.getString("attack"), 
									now.getString("name")));
					}
				}
				
				// was someone removed?
				if (PlanBoese.list.size() != arr.length()) {
					boolean keyFound;
					
					// yes, we must find him
					for (int key : PlanBoese.list.keySet()) {
						keyFound = false;
						
						for (int i=0; i<arr.length(); i++) {
							now = arr.getJSONObject(i);
							if (key == Integer.parseInt(now.getString("id"))) {
								keyFound = true;
								break;
							}
						}
						if (!keyFound) {
							// Found one, delete him from list
							PlanBoese.list.remove(key);
							if (PlanBoese.list.size() == arr.length()) {
								break;
							}
						}
					}
				}
				
				Output.noteln("-- Current List -- Name: Count fights");
				for (int key : PlanBoese.list.keySet()) {
					Output.noteln(PlanBoese.list.get(key).name + ": " + PlanBoese.list.get(key).fights);
				}
				Output.noteln("");

				int nextKey = 0;
				
				// From up to down?
				if (this.straight == 1) {
					int fights = -1;
					
					// go through the list
					for (int key : PlanBoese.list.keySet()) {
						if (fights == -1 && PlanBoese.list.get(key).canFight()) {
							nextKey = key;
							fights = PlanBoese.list.get(key).fights;
						}
						if (PlanBoese.list.get(key).fights < fights && PlanBoese.list.get(key).canFight()) {
							nextKey = key;
							fights = PlanBoese.list.get(key).fights;
						}
					}
					
					if (fights == -1) {
						throw new BadOpponent("", "");
					}
					
				// Find someone by random
				} else {
					Integer[] keys = PlanBoese.list.keySet().toArray(new Integer[0]);
					Random generator = new Random();
					nextKey = keys[generator.nextInt(keys.length)];
				}
					
				try {
					ins.fight(PlanBoese.list.get(nextKey).attack, PlanBoese.list.get(nextKey).name);
					PlanBoese.list.get(nextKey).fights++;
					
				} catch (BadOpponent e) {
					PlanBoese.list.get(nextKey).canFight = false;
					return false;
				}
					
				return true;
			} else {
				throw new NoList();
			}
		} catch (JSONException e){
			Output.noteln(e.getMessage());
		}
		return false;
	}
	
	public final static void initiate() {
		PlanBoese.list = null;
	}
	
	private final JSONArray getList(Instance i) throws NoList {
		Output.noteln("Get enemies list");
		try {
			HttpResponse response;
			
			// send post 
			HttpGet http = new HttpGet("http://www.bundeskampf.com/fights/enemysListJson");
			
			// Create a response handler
			response = i.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();
			JSONArray arr;

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
				arr = ob.getJSONArray("list");
				resEntity.consumeContent();
			} else {
				arr = new JSONArray();
			}
			return arr;

		} catch (JSONException e) {
			Output.println("No list avalible");
		} catch (Exception e) {
			Output.error(e);
			Output.println("No list avalible");
		}
		throw new NoList();
	}
	
	private final class NoList extends Exception {
		private static final long serialVersionUID = -2317742009841698364L;
	}
	
	private final class Opponent {
		public final String attack;
		public final String name;
		public int fights = 0;
		public boolean canFight = true;
		public Calendar countDate;
		
		public Opponent (String attack, String name) {
			this.attack = attack;
			this.name = name;
			this.countDate = new GregorianCalendar();
		}
		
		public final boolean canFight() {
			return (this.fights < Control.maxFights) && this.canFight;
		}
		
		public final void checkFightCounts() {
			Calendar today = new GregorianCalendar();
			today.set(
					Calendar.YEAR,
					Calendar.MONTH,
					Calendar.DAY_OF_YEAR,
					0,
					0);
			if (this.countDate.before(today)) {
				this.countDate = new GregorianCalendar();
				
				// Set all counters to zero
				this.fights = 0;
				this.canFight = true;
			}
		}
	}
}
