
import java.util.ArrayList;
import java.util.List;

import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.googleapis.ajax.common.PagedList;
import com.googleapis.ajax.schema.WebResult;
import com.googleapis.ajax.services.GoogleSearchQueryFactory;
import com.googleapis.ajax.services.WebSearchQuery;


public class Tagesquiz {
	
	public long[] result;
	private boolean debug;
	
	public Tagesquiz(boolean debug) throws Exception {
		this.debug = debug;
		this.result = new long[4]; 
				
		Main.sinnlos("http://www.bundeskampf.com/quiz/");

		// Post senden
		HttpPost http = new HttpPost("http://www.bundeskampf.com/quiz/GetQuestions");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("type", "gold"));
		
		http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		// Create a response handler
		HttpResponse response = Main.httpclient.execute(http);
		HttpEntity resEntity = response.getEntity();

		if (resEntity != null) {
	
			JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
			JSONObject result = new JSONObject(js);
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			JSONObject list;
			String questions[];
			try {
				list = result.getJSONObject("list");
				questions = JSONObject.getNames(list);
			} catch(JSONException e) {
				System.out.print("Quiz is done for today.");
				return;
			}
			
			
			
			for(String quest : questions) {
				JSONObject question = list.getJSONObject(quest);
				JSONObject choices = question.getJSONObject("choices");
				
				this.debug(question.getString("question"));
				
				String[] choice = new String[4];
				choice[0] = choices.getString("1");
				choice[1] = choices.getString("2");
				choice[2] = choices.getString("3");
				choice[3] = choices.getString("4");
				
				int choose = 0;
				
				JSONObject find = this.find(quest);
				if (find != null && find.getBoolean("result")) {
					for(int i=0; i<4; i++) {
						if (find.getString("answer").equals(choice[i])) {
							choose = i;
							break;
						}
					}
					if (choose == 0) {
						choose = find.getInt("answerId");
					}
				} else {
					choose = this.askQuestion(question.getString("question"), choice);
				}
				
				HttpPost http2 = new HttpPost("http://www.bundeskampf.com/quiz/GetAnswer/"+quest);
				List <NameValuePair> nvps2 = new ArrayList <NameValuePair>();
				nvps2.add(new BasicNameValuePair("answer", ""+(choose+1)));
				
				http2.setEntity(new UrlEncodedFormEntity(nvps2, HTTP.UTF_8));
				// Create a response handler
				HttpResponse response2 = Main.httpclient.execute(http2);
				HttpEntity resEntity2 = response2.getEntity();

				if (resEntity2 != null) {
					JSONTokener js2 = new JSONTokener(EntityUtils.toString(resEntity2));
					JSONObject result2 = new JSONObject(js2);
					if (resEntity2 != null) {
						resEntity2.consumeContent();
					}
					int answer = result2.getInt("result");
					answer--;
					String output = choice[choose];
					if (answer == choose) {
						output += " CORRECT";
					} else {
						output += " FAILED\n";
						output += choice[answer];
					}
					if (find != null && find.getBoolean("result")) {
						output += "\n== Answer came from database ==\n";
						output += find.toString();
					}
					this.debug(output);
					this.save(quest, choice[answer], answer, question.getString("question"));
				}
			}
			/*
			{"seconds":120,"list":{"13082051":
			{"question":"Was ist ein Fingertier?","answered":"0","choices":{"1":"Halbaffe","2":"Spielfigur","3":"Krake","4":"Krankheit"}}
			,"13082054":{"question":"Was bedeutet die Abk\u00fcrzung VfvB?","answered":"0","choices":{"1":"Verein f\u00fcr volkst\u00fcmliche Bewegungsspiele","3":"Verein f\u00fcr visuelle Bewegungsabl\u00e4ufe","4":"Verein f\u00fcr vorbildliche Berufsauffassung","2":"Verein f\u00fcr In-vitro-Biochemiker"}},
			"13082057":{"question":"Was war der urspr\u00fcngliche Zweck des Oldenburger Wunderhorns?","answered":"0","choices":{"4":"Man trank daraus.","3":"Man blies darauf zur Beerdigung.","1":"Man las darin M\u00e4rchen und Fabeln.","2":"Man verteidigte sich damit."}}
			,"13082060":{"question":"Was ist K\u00f6lnisch Wasser?","answered":"0","choices":{"1":"ein Parf\u00fcm","2":"Wasser aus dem Rhein","4":"ein Schnaps","3":"ein Malzbier"}}
			,"13082059":{"question":"Wohin besteht von Rostock aus keine regelm\u00e4\u00dfige F\u00e4hrverbindung?","answered":"0","choices":{"3":"Niederlande","4":"Schweden","1":"D\u00e4nemark","2":"Russland"}}
			,"13082058":{"question":"Auripolis ist der lateinische Name der bayerischen Stadt ...?","answered":"0","choices":{"2":"Ingolstadt","1":"Neu-Ulm","4":"W\u00fcrzburg","3":"Augsburg"}}
			,"13082055":{"question":"Wie hei\u00dft der Chefpathologe in der Serie Navy CIS?","answered":"0","choices":{"4":"Donald Ducky Mallard","2":"Jethro Gibbs","1":"Anthony Tony de Nozzo","3":"Timothy McGee"}}
			,"13082052":{"question":"Wie nennt man die Person, die ein Buch geschrieben hat?","answered":"0","choices":{"1":"Autor","3":"Buchschreiber","2":"Geschichtenausdenker","4":"Texter"}}
			,"13082056":{"question":"Was ist der s\u00fcdamerikanische Begriff Zouk?","answered":"0","choices":{"2":"Tanzstil in Brasilien","3":"Kolumbianischer Kampfsport","1":"Linksgerichtete politische Partei in Brasilien","4":"Brasilianisches Nationalgericht (Bohnen mit Zwiebeln und Knoblauch)"}}
			,"13082053":{"question":"Was ist der Hamburger Michel?","answered":"0","choices":{"2":"eine Kirche","1":"ein Museum","3":"ein Gericht am Hafen","4":"ein Restaurant"}}}}
			*/
			
			HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quiz/GetQuestions");
			
			// Create a response handler
			response = Main.httpclient.execute(httpget);
		    
			resEntity = response.getEntity();

			if (resEntity != null) {
				js = new JSONTokener(EntityUtils.toString(resEntity));
				result = new JSONObject(js);
				if (resEntity != null) {
					resEntity.consumeContent();
				}
				JSONObject reward = result.getJSONObject("reward");
				int value = reward.getInt("value");
				String korrekt = reward.getString("korrekt");
				System.out.println("Quiz: get "+value+" money, with "+korrekt+" correct");
			}
		}
	}

	private void save(String qid, String answer, int answerId, String question) {
		try {
			// Post senden
			HttpPost http = new HttpPost(Main.configQuizPath + qid);
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("answer", answer));
			nvps.add(new BasicNameValuePair("answerId", String.valueOf(answerId)));
			nvps.add(new BasicNameValuePair("question", question));
			
			http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			// Create a response handler
			HttpResponse response = Main.httpclient.execute(http);
			HttpEntity resEntity = response.getEntity();
	
			if (resEntity != null) {
				resEntity.consumeContent();
			}
		} catch (Exception e) {
			return;
		}
	}

	private JSONObject find(String choice) {
		if (Main.configQuizPath == "") return null;
		
		try {
			HttpGet httpget = new HttpGet(Main.configQuizPath+choice);
			
			// Create a response handler
			HttpResponse response = Main.httpclient.execute(httpget);
		    
			HttpEntity resEntity = response.getEntity();
	
			if (resEntity != null) {
				JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
				if (resEntity != null) {
					resEntity.consumeContent();
				}
				return new JSONObject(js);
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}
	
	
	private void debug(String message) {
		if (this.debug) {
			Main.debug("QUIZ: "+message);
		}
	}
	
	private int askQuestion(String question, String[] possible) {
		SearchThread[] threads = new SearchThread[4];
		for(int i=0; i<threads.length; i++) {
			threads[i] = new SearchThread(question+" "+possible[i], i, this);
			threads[i].start();
		}
		for(int i=0; i<threads.length; i++) {
			try{ threads[i].join(); }catch(InterruptedException e){}
		}
		
		int ret = 0;
	    for (int i=0; i<4; i++) {
	        if (this.result[i] > this.result[ret]) {
	            ret = i;
	        }
	    }
	    
	    return ret;
	}
	
	public class SearchThread extends Thread {
		protected int result;
		protected String term;
		protected Tagesquiz quiz;
		
		public SearchThread(String searchterm, int result, Tagesquiz parent) {
			this.result = result;
			this.term = searchterm;
			this.quiz = parent;
		}
		
		public void run() {
			GoogleSearchQueryFactory factory = GoogleSearchQueryFactory.newInstance("applicationKey");
			
			WebSearchQuery query = factory.newWebSearchQuery();
			
			PagedList<WebResult> response = query.withQuery(this.term).list();
			this.quiz.result[this.result] = response.getEstimatedResultCount();
		}
	}
}
