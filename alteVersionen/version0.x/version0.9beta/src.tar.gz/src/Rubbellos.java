import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;


public class Rubbellos {

	public Rubbellos() throws Exception {
		for (int i=0; i<3; i++) {
			try {
				Main.sinnlos("http://www.bundeskampf.com/kiosk/");
				Main.sinnlos("http://www.bundeskampf.com/kiosk/losKaufen/");
				Main.sinnlos("http://www.bundeskampf.com/kiosk/lose/");
	
				HttpGet httpget = new HttpGet("http://www.bundeskampf.com/kiosk/getLos");
				
				// Create a response handler
				HttpResponse response = Main.httpclient.execute(httpget);
			    
				HttpEntity resEntity = response.getEntity();
	
				if (resEntity != null) {
					JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
					JSONObject result = new JSONObject(js);
					if (resEntity != null) {
						resEntity.consumeContent();
					}
					String type = result.getString("type");
					if (!type.equals("kein Gewinn")) {
						System.out.println("Los: WIN "+ type + ": "+result.getString("data"));
					}
					type = result.getString("extratype");
					if (!type.equals("kein Gewinn")) {
						System.out.println("Los: WIN "+ type + ": "+result.getString("extradata"));
					}
				}
				Thread.sleep(1500);
				Main.sinnlos("http://www.bundeskampf.com/kiosk/getLosWin");
			} catch (JSONException e) {
				Main.debug("All Rubbelloses for today");
				return;
			}
		}
	}
}
