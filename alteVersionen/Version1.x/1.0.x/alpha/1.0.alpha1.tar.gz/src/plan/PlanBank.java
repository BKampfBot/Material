package plan;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public class PlanBank extends PlanObject {
	private int money;

	public PlanBank(JSONObject object) throws FatalError {
		this.setName("Bank");
		
		try {
			this.money = object.getInt("Bank");
		} catch (JSONException e) {
			throw new FatalError("Config error: Bank have to be an integer");
		}
		
		if (this.money < 0) {
			Output.error("Config: Bank is set to 0.");
			this.money = 0;
		}
	}
	

}
