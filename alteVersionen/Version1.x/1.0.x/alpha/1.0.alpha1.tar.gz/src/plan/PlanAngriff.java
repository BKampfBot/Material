package plan;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public class PlanAngriff extends PlanObject {
	private boolean club;
	private int level;

	public PlanAngriff(JSONObject object) throws FatalError {
		this.setName("Angriff");
		
		try {
			JSONObject angriff = object.getJSONObject("Angriff");
			
			int c = angriff.getInt("Verein");
			if (c == 0) this.club = false;
			else if (c == 1) this.club = true;
			else new FatalError("Config error: Verein have to be 1 or 0");
			
			this.level = angriff.getInt("Stufe");
		} catch (JSONException e) {
			throw new FatalError("Config error: Angriff config is bad");
		}
	}
}
