package plan;

import control.Control;
import output.FatalError;
import output.Output;
import json.JSONObject;

public class PlanStopp extends PlanObject {

	public PlanStopp(JSONObject object) throws FatalError {
		this.setName("Stopp");
	}
	
	public void run() {
		Output.println("-> Stopp");
		Control.safeExit();
	}

}
