package plan;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public class PlanMinuten extends PlanObject {
	private int count;

	public PlanMinuten(JSONObject object) throws FatalError {
		this.setName("Minuten");
		
		try {
			this.count = object.getInt("Minuten");
		} catch (JSONException e) {
			throw new FatalError("Config error: Minuten have to be an integer");
		}
		
		if (this.count < 0) {
			Output.error("Config: Minuten is set to 0.");
			this.count = 0;
		}
	}
	

}
