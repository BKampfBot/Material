package control;

public class BadOpponent extends Exception {
	private static final long serialVersionUID = 201102030046L;
	private String attack;
	private String name;
	
	public BadOpponent(String attack, String name) {
		this.attack = attack;
		this.name = name;
	}
	
	public String getAttack() {
		return this.attack;
	}
	public String getName() {
		return this.name;
	}
}
