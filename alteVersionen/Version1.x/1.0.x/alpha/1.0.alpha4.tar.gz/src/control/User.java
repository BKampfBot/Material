package control;

public class User {
	public enum Status { work, training, service, nothing }
	
	private int livepoints = 0;
	private int currentLivepoints = 0;
	private int level = 0;
	private String race = "";
	private String race2 = "xxx";
	private Status status = Status.nothing;
	private int fights = 0;
	private int lostFights = 0;
	private int winFights = 0;
	private int lostMoney = 0;
	private int winMoney = 0;
	private int placeOfHonor = 0;
		
	public int getFights() {
		return this.fights;
	}
	public void setFights(int fights) {
		this.fights = fights;
	}
	public int getLostMoney() {
		return this.lostMoney;
	}
	public void setLostMoney(int lostMoney) {
		this.lostMoney = lostMoney;
	}
	public int getWinMoney() {
		return this.winMoney;
	}
	public void setWinMoney(int winMoney) {
		this.winMoney = winMoney;
	}
	public int getPlaceOfHonor() {
		return this.placeOfHonor;
	}
	public void setPlaceOfHonor(int placeOfHonor) {
		this.placeOfHonor = placeOfHonor;
	}
	public Status getStatus() {
		return this.status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public int getLivepoints() {
		return this.livepoints;
	}
	public void setLivepoints(int livepoints) {
		this.livepoints = livepoints;
	}
	public int getCurrentLivepoints() {
		return this.currentLivepoints;
	}
	public void setCurrentLivepoints(int currentLivepoints) {
		this.currentLivepoints = currentLivepoints;
	}
	public int getLevel() {
		return this.level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getRace() {
		return this.race;
	}
	public String getRace2() {
		return this.race2;
	}
	public void setRace(String race) {
		this.race = race.trim();
		if (this.race.compareToIgnoreCase("Meck.-Vorp.") == 0) {
			this.race2 = "Mecklenburg-Vorpommern";
		} else if (this.race.compareToIgnoreCase("Bad.Württ.") == 0) {
			this.race2 = "Baden-Württemberg";
		}
		// "Nordrhein-Westfalen"
		// "Hessen"
		// "Sachsen-Anhalt"
	}
	public void addWinMoney(int money) {
		this.winMoney += money;
		this.fights++;
		this.winFights++;
	}
	public void addLostMoney(int money) {
		this.lostMoney += money;	
		this.fights++;
		this.lostFights++;
	}
}
