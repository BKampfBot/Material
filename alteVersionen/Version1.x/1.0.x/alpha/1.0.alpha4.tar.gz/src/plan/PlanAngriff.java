package plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.BadOpponent;
import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public class PlanAngriff extends PlanObject {
	public enum Club { No, Yes, Whatever };
	private Club club;
	private int level;

	public PlanAngriff(JSONObject object) throws FatalError {
		this.setName("Angriff");
		
		try {
			JSONObject angriff = object.getJSONObject("Angriff");
			
			int c = angriff.getInt("Verein");
			if (c == 0) this.club = Club.Whatever;
			else if (c == 1) this.club = Club.Yes;
			else if (c == -1) this.club = Club.No;
			else new FatalError("Config error: Verein have to be 1,-1 or 0");
			
			this.level = angriff.getInt("Stufe");
		} catch (JSONException e) {
			throw new FatalError("Config error: Angriff config is bad");
		}
	}
	
	public void run() throws IOException {
		Instance ins = Control.current;
		Output.println(
				"-> Angriff (Verein: " +
				(this.club.equals(Club.Yes)? "Ja":"") +
				(this.club.equals(Club.No)? "Nein":"") +
				(this.club.equals(Club.Whatever)? "Egal":"") +
				", Level: " +
				String.valueOf(this.level + ins.user.getLevel()) +
				")");

		try {
			boolean result = false;
			for (int i=0; i<30 && !result; i++) {
				if (i != 0) Output.println("Didn't find someone to fight. Will try again.");
				result = this.completeFight(ins);
			}
			if (!result) Output.println("Will abort fighting. (Didn't find an opponent.)");
		} catch (NoList l) {
			Output.error("Will abort fighting. (No list avalible.)");
		}
	}
	
	private boolean completeFight(Instance ins) throws NoList, IOException { 
		ins.visit("http://www.bundeskampf.com/fights/start");
		
		try {
			int level = this.level + ins.user.getLevel();
			JSONArray arr = this.getList(ins, level);
			JSONObject now;
			
			// TODO 
			Output.println(arr.toString());
			
			// If list is avalible
			if (arr.length() > 0) {
				for (int i=0; i<arr.length(); i++) {
					now = arr.getJSONObject(i);
					
					boolean guild;
					try {
						now.getInt("guild");
						guild = false;
					} catch (JSONException e) {
						guild = true;
					}
					
					if (now.getInt("level") == level
						&& !now.getString("race").equalsIgnoreCase(ins.user.getRace())
						&& !now.getString("race").equalsIgnoreCase(ins.user.getRace2())
						&& (	this.club.equals(Club.Whatever) || 
								(guild && this.club.equals(Club.Yes)) ||
								(!guild && this.club.equals(Club.No)))) {
						try {
							int result = ins.fight(now.getString("attack"), now.getString("name"));
							
							// Fight was won, we safe the opponent
							if (result > ins.getMoneyFightAgain()) {
								// TODO save
							
							// Fight was lost
							} else if (result == -1) {
								// TODO save
							}
						} catch (BadOpponent e) {
							// TODO save
						}
						
						return true;
					}
				}
				
				
			} else {
				throw new NoList();
			}
		} catch (JSONException e){
		}
		return false;
	}
	
	private JSONArray getList(Instance i, int level) throws NoList {
		Output.noteln("Get opponent list");
		try {
			HttpResponse response;
			
			// send post 
			HttpPost http = new HttpPost("http://www.bundeskampf.com/fights/opponentsListJson");
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("selectRace", "0"));
			nvps.add(new BasicNameValuePair("selectLevel", String.valueOf(level)));
			
			http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			// Create a response handler
			response = i.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();
			JSONArray arr;

			if (resEntity != null) {
				String s = EntityUtils.toString(resEntity);
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
				arr = ob.getJSONArray("list");
				resEntity.consumeContent();
			} else {
				arr = new JSONArray();
			}
			return arr;

		} catch (JSONException e) {
			Output.println("No list avalible");
			Output.error(e);
		} catch (Exception e) {
			Output.error(e);
			Output.println("No list avalible");
		}
		throw new NoList();
	}
	
	public class NoList extends Exception {
		private static final long serialVersionUID = -2317742009841698364L;
	}
}
