package plan;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.Control;
import control.Instance;
import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public class PlanArbeiten extends PlanObject {
	private int hours;

	public PlanArbeiten(JSONObject object) throws FatalError {
		this.setName("Arbeiten");
		
		try {
			this.hours = object.getInt("Arbeiten");
		} catch (JSONException e) {
			throw new FatalError("Config error: Arbeiten have to be an integer");
		}
		
		if (this.hours < 1) {
			Output.error("Config: Arbeiten is set to 1 hour.");
			this.hours = 1;
		} else if (this.hours > 10) {
			Output.error("Config: Arbeiten is set to 10 hours.");
			this.hours = 10;
		}
	}
	
	public void run() throws ClientProtocolException, IOException, JSONException, FatalError {
		Output.println("-> Arbeiten ("+this.hours+" hours)");
		
		Instance i = Control.current;
		
		i.visit("http://www.bundeskampf.com/arbeitsamt/index/gold");
		
		HttpResponse response;
		HttpEntity resEntity;
		
		// Post senden
		HttpPost http = new HttpPost("http://www.bundeskampf.com/services/index/gold/45");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("data[Service][duration]", String.valueOf(this.hours)));
		nvps.add(new BasicNameValuePair("[Service][txt]","Hier steht was"));
		
		http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		
		// Create a response handler
		response = i.httpclient.execute(http);
		resEntity = response.getEntity();

		if (resEntity != null) {
			resEntity.consumeContent();
		}
		
		try { Thread.sleep(500); } catch (InterruptedException e) {}
		
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/services/serviceData");
		
		// Create a response handler
		response = i.httpclient.execute(httpget);
	    
		resEntity = response.getEntity();
		
		if (resEntity != null) {
			JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
			JSONObject result = new JSONObject(js);
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			
			String workFee = result.getString("workFee");
			Output.noteln("Work for "+workFee+" money.");


			// cut it into parts to safe session
			int count = 60*this.hours+1;
			while (count > 10) {
				// sleep for 10 min
				Output.noteln("Will sleep for 10 min");
				try { Thread.sleep(600000); } catch (InterruptedException e) {}
				count -= 10;
				Control.current.getCharacter();
			}
			Output.noteln("Will sleep for "+count+" min");
			try { Thread.sleep(60000*count); } catch (InterruptedException e) {}
			
			
			i.visit("http://www.bundeskampf.com/arbeitsamt/finish");
		}	
	}
}
