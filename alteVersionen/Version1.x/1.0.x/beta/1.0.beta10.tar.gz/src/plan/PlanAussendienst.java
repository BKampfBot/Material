package plan;

import java.io.IOException;
import java.util.GregorianCalendar;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanAussendienst extends PlanObject {
	private int difficult;

	public PlanAussendienst(JSONObject object) throws FatalError {
		this.setName("Außendienst");
		
		try {
			this.difficult = object.getInt("Außendienst");
		} catch (JSONException e) {
			throw new FatalError("Config error: Außendienst have to be 0 or 1");
		}
		
		if (this.difficult > 1) {
			Output.error("Config: Außendienst is set to 1.");
			this.difficult = 1;
		} else if (this.difficult < 0) {
			Output.error("Config: Außendienst is set to 0.");
			this.difficult = 0;
		}
	}
	
	public final void run() throws ClientProtocolException, IOException, JSONException, FatalError {
		Output.println(
				"-> Außendienst (" +
				((this.difficult == 1)? "schwer":"leicht") +
				")");

		try {
			boolean result = false;
			for (int i=0; i<10 && !result; i++) {
				if (i != 0) {
					Output.println("Didn't get the task. Will try again in 2 minutes.");
					try { Thread.sleep(120000); } catch (InterruptedException e) {}
				}
				result = this.completeService();
			}
			if (!result) Output.println("Will abort do service. (Something goes wrong.)");
		} catch (MaxServices e) {
			Output.println("Max count of service for today.");
		}
	}
		
	public final static boolean finish() throws ClientProtocolException, IOException, FatalError {
		Instance ins = Control.current;
		
		// HTTP parameters stores header etc.
		HttpParams params = new BasicHttpParams();
		params.setParameter("http.protocol.handle-redirects",false);


		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quests/start");
		httpget.setParams(params);
		
		HttpResponse response = ins.httpclient.execute(httpget);

		// obtain redirect target
		Header locationHeader = response.getFirstHeader("location");
		HttpEntity resEntity = response.getEntity();
		if (resEntity != null) {
			resEntity.consumeContent();
		}
		if (locationHeader != null) {
			Output.noteln("Loaction: " + locationHeader.getValue());
			
			// difficult 
			if (locationHeader.getValue().equalsIgnoreCase("http://www.bundeskampf.com/quests/fight")) {
				Output.noteln("You selected a difficult service before and didn't finish it.");
				return PlanAussendienst.difficultFinish();
			} else if (locationHeader.getValue().equalsIgnoreCase("http://www.bundeskampf.com/quests/finish")) {
				Output.noteln("You selected a easy service before and didn't finish it.");
				return PlanAussendienst.easyFinish();
			} else if (locationHeader.getValue().equalsIgnoreCase("http://www.bundeskampf.com/quests/doQuest")) {
				
				httpget = new HttpGet("http://www.bundeskampf.com/quests/questData");
				response = ins.httpclient.execute(httpget);
				resEntity = response.getEntity();

				if (resEntity != null) {
					try {
						String s = EntityUtils.toString(resEntity);
						JSONObject o = new JSONObject(new JSONTokener(s));
						int serverTs = o.getJSONObject("time").getInt("server");
						int endTs = o.getJSONObject("time").getInt("realend");
						
						long miliSeconds = endTs-serverTs;
						miliSeconds *= 1000;
						miliSeconds += 30000;

						int z = Math.round(miliSeconds/60000);
						
						GregorianCalendar c = new GregorianCalendar();
						c.setTimeInMillis(new GregorianCalendar().getTimeInMillis()+miliSeconds);
						
						Output.println("Wait for finish service, in "+z+" Min ("+(c.getTime().toString())+")");
						
						try { Thread.sleep(miliSeconds); } catch (InterruptedException e) {}
						
						return PlanAussendienst.finish();
					} catch (JSONException e) {
						Output.error(e);
						return false;					
					}
				} else {
					Output.error("Something is wrong.");
					return false;
				}
			}
		}
		return true;
	}
	
	private final boolean completeService() throws MaxServices, ClientProtocolException, IOException, JSONException, FatalError {
		
		Instance ins = Control.current;

		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quests/start");		
		HttpResponse response = ins.httpclient.execute(httpget);

		HttpEntity resEntity = response.getEntity();
		
		if (resEntity != null) {
			String s = EntityUtils.toString(resEntity);
			if (s.indexOf("/img/images2/max.jpg") != -1) {
				throw new MaxServices();
			}
			String search = "var quests = ";
			int start = s.indexOf(search);
			if (start == -1) {
				return false;
			}
			
			start = s.indexOf('\n',start+search.length());
			start = s.indexOf('\n',start+2);
			int end = s.indexOf("]",start)+1;
			search = s.substring(start,end);
			
			search = "{list:["+search+"}";

			JSONObject o = new JSONObject( new JSONTokener(search));
			JSONObject now = o.getJSONArray("list").getJSONObject(this.difficult);
			
			Output.noteln("Take job: \""+now.getString("title")+"\"");
			
			ins.visit("http://www.bundeskampf.com/quests/start/"+now.getInt("questId")+"/0");
					
			try { Thread.sleep(500); } catch (InterruptedException e) {}
				    
			resEntity.consumeContent();

			httpget = new HttpGet("http://www.bundeskampf.com/quests/questData");
			response = ins.httpclient.execute(httpget);
			resEntity = response.getEntity();

			if (resEntity != null) {
				try {
					s = EntityUtils.toString(resEntity);
					o = new JSONObject(new JSONTokener(s));
					int serverTs = o.getJSONObject("time").getInt("server");
					int endTs = o.getJSONObject("time").getInt("realend");
					
					long miliSeconds = endTs-serverTs;
					miliSeconds *= 1000;
					miliSeconds += 30000;

					int z = Math.round(miliSeconds/60000);
					
					GregorianCalendar c = new GregorianCalendar();
					c.setTimeInMillis(new GregorianCalendar().getTimeInMillis()+miliSeconds);
					
					Output.println("Wait for finish, in "+z+" Min ("+(c.getTime().toString())+")");
					
					try { Thread.sleep(miliSeconds); } catch (InterruptedException e) {}
					
					if (this.difficult == 0) {
						return PlanAussendienst.easyFinish();
					} else {
						return PlanAussendienst.difficultFinish();
					}
				} catch (JSONException e) {
					throw new MaxServices();
				}
			}
		}
		return false;
	}

	private final static boolean difficultFinish() throws ClientProtocolException, IOException, FatalError {
		Instance ins = Control.current;
		
		try {
			ins.visit("http://www.bundeskampf.com/quests/finish");
			HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quests/fight");
			HttpResponse response = ins.httpclient.execute(httpget);
			HttpEntity resEntity = response.getEntity();
	
			if (resEntity != null) {
				String pageContent = EntityUtils.toString(resEntity);
				int first = pageContent.indexOf("<div style=\"position:absolute;left:0px;top:0px;width:344;height:675px;border-width:0px;\">");
				first = pageContent.indexOf("var flashvars = ", first);
				first += "var flashvars = ".length();
				int end = pageContent.indexOf("}", first)+1;
				String flashvars = pageContent.substring(first, end);
			
				
				JSONTokener tk = new JSONTokener(flashvars);
				JSONObject character = new JSONObject(tk);
				int fullSec = character.getInt("fullSec");
				String finishUrl = character.getString("finishUrl");
				
				ins.visit("http://www.bundeskampf.com"+finishUrl);
				
				Output.print("Result in "+fullSec+" seconds: ");
				
				try { Thread.sleep(fullSec*1000); } catch (InterruptedException e) {}
				
				resEntity.consumeContent();
				
				finishUrl = finishUrl.substring("/quests/results/".length());
				httpget = new HttpGet("http://www.bundeskampf.com/quests/resultsData/"+finishUrl);
				
				// Create a response handler
				response = ins.httpclient.execute(httpget);
			    resEntity = response.getEntity();
	
				if (resEntity != null) {
					pageContent = EntityUtils.toString(resEntity);
					tk = new JSONTokener(pageContent);
					character = new JSONObject(tk);
					if (character.getBoolean("fightWasWon")) {
						Output.println("Fight was won");
					} else {
						Output.println("Fight was lost");
					}
	
					resEntity.consumeContent();
					
					try { Thread.sleep(500); } catch (InterruptedException e) {}
				
					httpget = new HttpGet("http://www.bundeskampf.com/quests/endText");
					response = ins.httpclient.execute(httpget);
					resEntity = response.getEntity();
				
					if (resEntity != null) {
						pageContent = EntityUtils.toString(resEntity);
						resEntity.consumeContent();
						
						ins.waitForStatus();
					}
					return true;
				}
			}
		} catch (JSONException e) {
			Output.error(e);
			return false;
		}
		return false;
	}

	private final static boolean easyFinish() {
		Control.current.visit("http://www.bundeskampf.com/quests/finish");
		return true;
	}

	private final class MaxServices extends Exception {
		private static final long serialVersionUID = 201102041110L;
	}
}
