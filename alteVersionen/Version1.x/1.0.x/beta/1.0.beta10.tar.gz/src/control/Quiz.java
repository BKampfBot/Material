package control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import output.Output;


public final class Quiz {
	private Instance instance;
	
	public Quiz(Instance ins) throws ClientProtocolException, IOException {
		this.instance = ins;
		this.instance.visit("http://www.bundeskampf.com/quiz/");
		
		String secret = "097ab47f37712cc85170b78700daedea";
		
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quiz/GetQuestions/gold/"+secret);

		// Create a response handler
		HttpResponse response = this.instance.httpclient.execute(httpget);
		HttpEntity resEntity = response.getEntity();

		try {
			JSONObject result = new JSONObject(new JSONTokener(EntityUtils.toString(resEntity)));
			//JSONObject result = new JSONObject(new JSONTokener("{\"seconds\":120,\"list\":{\"18719189\":{\"question\":\"Wie hei\u00dft die Wissenschaft von den fossilen Pflanzen?\",\"answered\":0,\"choices\":{\"2\":\"Pal\u00e4obotanik\",\"4\":\"Arch\u00e4obotanik\",\"3\":\"Antikobotanik\",\"1\":\"Historobotanik\"},\"correctanswer\":\"8406724b4f7eb2dda648804a16957103\"},\"18719186\":{\"question\":\"Welche Prominente war in den so genannten Nipplegate-Skandal verwickelt?\",\"answered\":0,\"choices\":{\"2\":\"Janet Jackson\",\"3\":\"Paris Hilton\",\"4\":\"Lindsay Lohan\",\"1\":\"Halle Berry\"},\"correctanswer\":\"e1c55d56496ea301db6e94489a5dae54\"},\"18719184\":{\"question\":\"In welcher dieser St\u00e4dte findet man kein Schloss?\",\"answered\":0,\"choices\":{\"2\":\"Wilhelmshaven\",\"3\":\"Weimar\",\"4\":\"Dresden\",\"1\":\"Berlin\"},\"correctanswer\":\"a1776b4e50e4594533bc3d5ef88961d1\"},\"18719183\":{\"question\":\"Welcher dieser TV-Sender ist im Besitz von Silvio Berlusconi?\",\"answered\":0,\"choices\":{\"1\":\"Tele 5\",\"2\":\"Neun Live\",\"3\":\"Viva\",\"4\":\"RTL 2\"},\"correctanswer\":\"94383bf8e653a8a75ac380cd355fa776\"},\"18719181\":{\"question\":\"Wobei handelt es sich um eine Film-Trilogie?\",\"answered\":0,\"choices\":{\"4\":\"Zur\u00fcck in die Zukunft\",\"2\":\"Titanic\",\"1\":\"A beautiful Mind\",\"3\":\"Contact\"},\"correctanswer\":\"e796523f8ef279759d33ad5e5ed58e69\"},\"18719188\":{\"question\":\"Wer spielt die Hauptrolle in Die Legende des Zorro?\",\"answered\":0,\"choices\":{\"4\":\"Antonio Banderas\",\"3\":\"Sean Connery\",\"2\":\"Alain Delon\",\"1\":\"Tom Hanks\"},\"correctanswer\":\"0a73d315eaab9e15f448c87009459804\"},\"18719190\":{\"question\":\"Welches Ma\u00df gab ein Bauer fr\u00fcher f\u00fcr eine Ackerfl\u00e4che an?\",\"answered\":0,\"choices\":{\"1\":\"Morgen\",\"4\":\"Gestern\",\"3\":\"Heute\",\"2\":\"Heurig\"},\"correctanswer\":\"3fcefa841597b9ee846d71612fab785b\"},\"18719185\":{\"question\":\"Wie hei\u00dft der Baum, der traditionell in Bayern Paaren in den Garten gepflanzt wird, die nach siebenj\u00e4hrigem Zusammenleben noch immer nicht geheiratet haben?\",\"answered\":0,\"choices\":{\"3\":\"Hungerbaum\",\"4\":\"Durstbaum\",\"2\":\"Tr\u00f6delbaum\",\"1\":\"Ewigkeitsbaum\"},\"correctanswer\":\"ea0e664495ffe6d0c219e40e736a1c92\"},\"18719187\":{\"question\":\"Wie ruft man in Berlin zu Karneval?\",\"answered\":0,\"choices\":{\"4\":\"Berlin Hajo!\",\"1\":\"Berlin Alaaf!\",\"3\":\"Berlin Helau!\",\"2\":\"Berlin Aja!\"},\"correctanswer\":\"831971d1c96e254a791a038e728b7272\"},\"18719182\":{\"question\":\"Welches Tier gilt als geheimes Wappentier Islands?\",\"answered\":0,\"choices\":{\"3\":\"Papageientaucher\",\"4\":\"Islandpferd\",\"2\":\"Polarfuchs\",\"1\":\"Eissturmvogel\"},\"correctanswer\":\"8130e01dac15f32b09bd4b7f5b6c9293\"}}}"));
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			
			JSONObject list;
			String questions[];
			try {
				list = result.getJSONObject("list");
				questions = JSONObject.getNames(list);
			} catch(JSONException e) {
				Output.println("Quiz is done for today.");
				return;
			}
			
			Output.noteln("Get questions:");
			
			JSONArray answers = new JSONArray();
			JSONObject answer;
			
			for(String quest : questions) {
				JSONObject question = list.getJSONObject(quest);
				JSONObject choices = question.getJSONObject("choices");
				
				answer = new JSONObject();
				answer.put("answer", 1);
				answer.put("id", Integer.valueOf(quest));
				answer.put("number", Integer.valueOf(choices.getInsertOrder()[0]));
				
				Output.noteln(question.getString("question"));
				Output.noteln(choices.getString(choices.getInsertOrder()[0]));
				answers.put(answer);
			}					

			int time = new Random().nextInt(10)+30;
			Output.noteln("Will wait "+time+" seconds");
			try { Thread.sleep(time*1000); } catch (InterruptedException e) {}
			
			HttpPost http = new HttpPost("http://www.bundeskampf.com/quiz/GetReward");
			List <NameValuePair> nvps2 = new ArrayList <NameValuePair>();
			nvps2.add(new BasicNameValuePair("result", answers.toString()));
			nvps2.add(new BasicNameValuePair("secret", secret));
			nvps2.add(new BasicNameValuePair("time", String.valueOf(time)));
			
			http.setEntity(new UrlEncodedFormEntity(nvps2, HTTP.UTF_8));
			// Create a response handler
			response = this.instance.httpclient.execute(http);
			resEntity = response.getEntity();
			//errorStatus=ok&reward=108&rewardtype=gold
			String result2 = EntityUtils.toString(resEntity);
			if (!result2.matches(".*errorStatus=ok.*")) {
				Output.println("Something went wrong");
			} else {
				Output.println("Get "+result2.replaceAll("[^0-9]", "")+ " money");
			}
			if (resEntity != null) {
				resEntity.consumeContent();
			}
		} catch (JSONException e) {
			Output.error(e);
			return;
		}
	}
}