package control;

public class RestartLater extends Exception {
	private static final long serialVersionUID = 201102060227L;
	
	public RestartLater() {
		super();
	}
	
	public RestartLater(String message) {
		super(message);
	}
}
