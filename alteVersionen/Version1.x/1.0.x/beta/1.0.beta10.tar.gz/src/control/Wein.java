package control;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import json.JSONObject;
import json.JSONTokener;
import output.Output;

public final class Wein {
	
	public Wein(Instance ins) {
		try {
			
			String s = ins.getString("http://www.bundeskampf.com/guild_challenge/index");
			int i = s.indexOf("var flashvars = {");
			i = s.indexOf("var flashvars = {", i+1);
			i = s.indexOf("var flashvars = {", i+1);
			s = s.substring(s.indexOf("guild_id:", i+1));
			s = s.substring(0, s.indexOf('\n'));
			final String guild_id = s.replaceAll("[^0-9]", "");
			
			
			JSONObject result = new JSONObject(
								new JSONTokener(
								ins.getString(
								"http://www.bundeskampf.com/guild_challenge/getData/" + guild_id)));
			
			if (result.getInt("game") == 1) {
				
				ins.visit("http://www.bundeskampf.com/games/kisten/0");
				
				JSONObject befor = new JSONObject(
						new JSONTokener(
						ins.getString("http://www.bundeskampf.com/games/getGameWarehouse")));
				
				int wait = new Random().nextInt(30)+30;
				Output.noteln("Wait "+wait+" seconds");
				try { Thread.sleep(wait*1000); } catch (InterruptedException e) {}
						
				String md5;
				try {
					MessageDigest m = MessageDigest.getInstance("MD5");
					byte[] data = ("U9ZF6FG7WDDSW453WIN" + befor.getString("hash")).getBytes(); 
					m.update(data,0,data.length);
					BigInteger in = new BigInteger(1,m.digest());
					md5 = String.format("%1$032X", in);
				} catch (NoSuchAlgorithmException e) {
					Output.error(e);
					return;
				}

				md5 = md5.toLowerCase();
				
				JSONObject win = new JSONObject(
						new JSONTokener(
						ins.getString("http://www.bundeskampf.com/games/punkteWarehouse/"+md5)));
				
				if (win.getInt("result") == 1) {
					Output.println("Weinkeller: WIN");
				} else {
					Output.println("Weinkeller: LOST");
				}
			} else {
				Output.println("Weinkeller: done");
			}
		} catch (Exception e) {
			Output.error(e);
		}
	}
}
