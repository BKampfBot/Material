package control;

public final class User {
	public enum Status { work, training, service, nothing }
	
	private int livepoints = 0;
	private int currentLivepoints = 0;
	private int level = 0;
	private String race = "";
	private String race2 = "xxx";
	private Status status = Status.nothing;
	private int fights = 0;
	private int lostFights = 0;
	private int winFights = 0;
	private int lostMoney = 0;
	private int winMoney = 0;
	private int placeOfHonor = 0;
		
	public final int  getFights() {
		return this.fights;
	}
	public final void  setFights(int fights) {
		this.fights = fights;
	}
	public final int  getLostMoney() {
		return this.lostMoney;
	}
	public final void  setLostMoney(int lostMoney) {
		this.lostMoney = lostMoney;
	}
	public final int  getWinMoney() {
		return this.winMoney;
	}
	public final void  setWinMoney(int winMoney) {
		this.winMoney = winMoney;
	}
	public final int  getPlaceOfHonor() {
		return this.placeOfHonor;
	}
	public final void  setPlaceOfHonor(int placeOfHonor) {
		this.placeOfHonor = placeOfHonor;
	}
	public final Status  getStatus() {
		return this.status;
	}
	public final void  setStatus(Status status) {
		this.status = status;
	}
	public final int  getLivepoints() {
		return this.livepoints;
	}
	public final void  setLivepoints(int livepoints) {
		this.livepoints = livepoints;
	}
	public final int  getCurrentLivepoints() {
		return this.currentLivepoints;
	}
	public final void  setCurrentLivepoints(int currentLivepoints) {
		this.currentLivepoints = currentLivepoints;
	}
	public final int  getLevel() {
		return this.level;
	}
	public final void  setLevel(int level) {
		this.level = level;
	}
	public final String  getRace() {
		return this.race;
	}
	public final String  getRace2() {
		return this.race2;
	}
	public final void  setRace(String race) {
		this.race = race.trim();
		if (this.race.compareToIgnoreCase("Meck.-Vorp.") == 0) {
			this.race2 = "Mecklenburg-Vorpommern";
		} else if (this.race.compareToIgnoreCase("Bad.Württ.") == 0) {
			this.race2 = "Baden-Württemberg";
		}
		// "Nordrhein-Westfalen"
		// "Hessen"
		// "Sachsen-Anhalt"
		// Thüringen -> OK
	}
	public final void  addWinMoney(int money) {
		this.winMoney += money;
		this.fights++;
		this.winFights++;
	}
	public final void  addLostMoney(int money) {
		this.lostMoney += money;	
		this.fights++;
		this.lostFights++;
	}
}
