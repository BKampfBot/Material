package plan;

import control.RestartLater;
import output.FatalError;
import output.Output;
import json.JSONObject;

public final class PlanNeustart extends PlanObject {

	public PlanNeustart(JSONObject object) throws FatalError {
		this.setName("Neustart");
	}
	
	public final void run() throws RestartLater {
		Output.println("-> Neustart");
		throw new RestartLater("Neustart");
	}

}
