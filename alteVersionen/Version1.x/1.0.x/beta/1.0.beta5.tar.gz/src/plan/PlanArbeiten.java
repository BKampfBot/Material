package plan;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.Control;
import control.Instance;
import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanArbeiten extends PlanObject {
	private int hours;

	public PlanArbeiten(JSONObject object) throws FatalError {
		this.setName("Arbeiten");
		
		try {
			this.hours = object.getInt("Arbeiten");
		} catch (JSONException e) {
			throw new FatalError("Config error: Arbeiten have to be an integer");
		}
		
		if (this.hours < 1) {
			Output.error("Config: Arbeiten is set to 1 hour.");
			this.hours = 1;
		} else if (this.hours > 10) {
			Output.error("Config: Arbeiten is set to 10 hours.");
			this.hours = 10;
		}
	}
	
	public final void run() throws ClientProtocolException, IOException, JSONException, FatalError {
		Output.println("-> Arbeiten ("+this.hours+" hours)");
		
		Instance i = Control.current;
		
		i.visit("http://www.bundeskampf.com/arbeitsamt/index/gold");
		
		HttpResponse response;
		HttpEntity resEntity;
		
		// Post senden
		HttpPost http = new HttpPost("http://www.bundeskampf.com/services/index/gold/45");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("data[Service][duration]", String.valueOf(this.hours)));
		nvps.add(new BasicNameValuePair("[Service][txt]","Hier steht was"));
		
		http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		
		// Create a response handler
		response = i.httpclient.execute(http);
		resEntity = response.getEntity();

		if (resEntity != null) {
			resEntity.consumeContent();
		}
		
		try { Thread.sleep(500); } catch (InterruptedException e) {}
		
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/services/serviceData");
		
		// Create a response handler
		response = i.httpclient.execute(httpget);
	    
		resEntity = response.getEntity();
		
		if (resEntity != null) {
			JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
			JSONObject result = new JSONObject(js);
			if (resEntity != null) {
				resEntity.consumeContent();
			}
			
			String workFee = result.getString("workFee");
			Output.noteln("Work for "+workFee+" money.");


			// cut it into parts to safe session
			int count = 60*this.hours+1;
			while (count > 10) {
				// sleep for 10 min
				Output.noteln("Will sleep for 10 min");
				try { Thread.sleep(600000); } catch (InterruptedException e) {}
				count -= 10;
				Control.current.getCharacter();
			}
			Output.noteln("Will sleep for "+count+" min");
			try { Thread.sleep(60000*count); } catch (InterruptedException e) {}
			
			
			i.visit("http://www.bundeskampf.com/arbeitsamt/finish");
		}	
	}

	public final static boolean finish() throws ClientProtocolException, IOException, FatalError {
		Instance ins = Control.current;
		
		// HTTP parameters stores header etc.
		HttpParams params = new BasicHttpParams();
		params.setParameter("http.protocol.handle-redirects",false);


		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/arbeitsamt/index");
		httpget.setParams(params);
		
		HttpResponse response = ins.httpclient.execute(httpget);

		// obtain redirect target
		Header locationHeader = response.getFirstHeader("location");
		HttpEntity resEntity = response.getEntity();
		if (resEntity != null) {
			resEntity.consumeContent();
		}
		if (locationHeader != null) {
			Output.noteln("Loaction: " + locationHeader.getValue());
			
			if (locationHeader.getValue().equalsIgnoreCase("http://www.bundeskampf.com/arbeitsamt/serve")) {
				try {
					httpget = new HttpGet("http://www.bundeskampf.com/services/serviceData");
					
					// Create a response handler
					response = ins.httpclient.execute(httpget);
				    
					resEntity = response.getEntity();
					
					if (resEntity != null) {
						JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
						JSONObject result = new JSONObject(js);
						resEntity.consumeContent();
						
						// [truncated] {"currentTime":43,"fullTime":3600,"urlCancel":"\/arbeitsamt\/cancel","urlFinish":"\/arbeitsamt\/finish","workTotalTime":"1","workFee":"112","workFeeType":"gold","workText":"Die Kellnerin im Goldenen Igel kommt nach einem langen
						int seconds = result.getInt("fullTime") - result.getInt("currentTime") + 20;
						Output.println("Last work is not finished. Will wait " + Math.round(seconds/60) + " min.");
						
						// cut it into parts to safe session
						while (seconds > 600) {
							// sleep for 10 min
							Output.noteln("Will sleep for 10 min");
							try { Thread.sleep(600000); } catch (InterruptedException e) {}
							seconds -= 600;
							Control.current.getCharacter();
						}
						Output.noteln("Will sleep for "+Math.round(seconds/60)+" min");
						try { Thread.sleep(1000*seconds); } catch (InterruptedException e) {}
						
						
						ins.visit("http://www.bundeskampf.com/arbeitsamt/finish");
					}
				} catch (JSONException e) {
					Output.error(e);
					return false;
				}
			} else if (locationHeader.getValue().equalsIgnoreCase("http://www.bundeskampf.com/arbeitsamt/finish")) {
				ins.visit("http://www.bundeskampf.com/arbeitsamt/finish");
			} else {
				Output.error("Something is wrong.");
				return false;
			}
		}
		return true;
	}
}
