package output;

import java.io.File;
import java.io.FileWriter;
import java.util.Date;

import json.JSONObject;

public class InfoFile {
	public static String path = null;
	private static final String logPath = "/log/";
	
	final public static void initiate() {
		if (!new File(InfoFile.path).isDirectory()) {
			Output.error("Directory doesn't exist: "+InfoFile.path);
			InfoFile.path = null;
		}

		File logDir = new File(InfoFile.path+InfoFile.logPath);
		if (!logDir.isDirectory() && !logDir.mkdir()) {
			Output.error("Directory doesn't exist: "+InfoFile.path+InfoFile.logPath);
			InfoFile.path = null;
		}
	}
	
	final public static void writeLog(String text, String file) {
		if (path == null) {
			return;
		}
		
		try {
			File toWrite = new File(InfoFile.path+InfoFile.logPath+String.valueOf(new Date().getTime()));
			
			FileWriter writer = new FileWriter(toWrite);
			writer.write(text);
			if (file != null) {
				writer.write("\nurl:"+file);
			}
			writer.flush();
			writer.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	final public static void writeFightFile(JSONObject result) {
		if (path == null) {
			return;
		}
		
		
		try {
			JSONObject opponent = result.getJSONObject("opponent");
			
			String name = opponent.getString("name");
			name = name.replaceAll("[^a-zA-Z0-9]", "_");
			
			String filename = String.valueOf(new Date().getTime())+name+".html";
			
			InfoFile.writeLog(
					"fight:"+opponent.getString("name")+"\n"+
					"won:"+result.getJSONObject("results").getBoolean("fightWasWon")+"\n"+
					"money:"+result.getJSONObject("results").getJSONObject("p1").getInt("gold"), filename);
			File toWrite = new File(InfoFile.path+"/"+filename);
			
			/*if (!toWrite.canWrite()) {
				Output.error("File not writeable: "+InfoFile.path+"/"+opponent.getString("id")+name);
				return false;
			}*/
			
			FileWriter writer = new FileWriter(toWrite);
			writer.write(
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n" +
"<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">" +
"<head>" +
"<title>" + name + "</title>" +
"<meta http-equiv=\"content-type\" content=\"text/html;charset=utf-8\" />" +
"</head>" +
"<body>" +
"<div style=\"float:right\">" +
"<h2>Verein</h2>" +
"<table border=\"1\" style=\"width:100%;\">" +
"<tr><th>Schnellere Keilerei</th><td>"+opponent.getString("arena_bonus")+"</td></tr>" +
"<tr><th>Schnellerer Fortschritt</th><td>"+opponent.getString("ep_bonus")+"</td></tr>" +
"<tr><th>Eindruck</th><td>"+opponent.getString("plating_bonus")+"</td></tr>" +
"<tr><th>Respekt bewahren</th><td>"+opponent.getString("standing_bonus")+"</td></tr>" +
"<tr><th>Schwarzarbeit</th><td>"+opponent.getString("quest_gold_bonus")+"</td></tr>" +
"<tr><th>Rücklage</th><td>"+opponent.getString("lost_gold_bonus")+"</td></tr>" +
"<tr><th>Kassensturz</th><td>"+opponent.getString("won_gold_bonus")+"</td></tr>" +
"<tr><th>Boxenstopp</th><td>"+opponent.getString("quest_time_bonus")+"</td></tr>" +
"</table>" +
"<h2>Kampfserie</h2>" +
"<table border=\"1\" style=\"width:100%;\">" +
"<tr><th>Aktuell</th><td>"+opponent.getString("series_current")+"</td></tr>" +
"<tr><th>Max</th><td>"+opponent.getString("series_max")+"</td></tr>" +
"<tr><th>Sicherung</th><td>"+opponent.getString("safepoint")+"</td></tr>" +
"</table>" +
"<h2>Garage</h2>" +
"<table border=\"1\" style=\"width:100%;\">" +
"<tr><th>Fahrzeug</th><td>"+opponent.getString("ride_id")+"</td></tr>" +
"<tr><th>Antrieb</th><td>"+opponent.getString("ride_speed")+"</td></tr>" +
"<tr><th>Navi</th><td>"+opponent.getString("ride_weapon")+"</td></tr>" +
"<tr><th>Sound </th><td>"+opponent.getString("ride_shield")+"</td></tr>" +
"</table>" +
"</div>" +

"<table border=\"1\" style=\"width: 700px;\">" +
"<tr><td style=\"background-color:"+((result.getJSONObject("results").getBoolean("fightWasWon")?"green":"red"))+";\">"+((result.getJSONObject("results").getBoolean("fightWasWon")?"Gewonnen":"Verloren"))+"</td><th style=\"width: 40%;\">" + opponent.getString("name") + "</th><th style=\"width: 40%;\">Ich</th></tr>" +
"<tr><th>Nahkampfschaden</th><td>"+result.getJSONObject("results").getJSONObject("p2").getJSONObject("fightDamage").getInt("from")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getJSONObject("fightDamage").getInt("from") + "</td></tr>" +
"<tr><th>Dachschaden</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("magicDamage")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("magicDamage")+"</td></tr>" +
"<tr><th>Treffer</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("hits")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("hits")+"</td></tr>" +
"<tr><th>Kritische Treffer</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("criticalHits")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("criticalHits")+"</td></tr>" +
"<tr><th>Angriffe abgelenkt</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("blocked")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("blocked")+"</td></tr>" +
"<tr><th>Eindruck</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("platting")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("platting")+"</td></tr>" +
"<tr><th>Lebensenergie</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("lp")+"/"+result.getJSONObject("results").getJSONObject("p2").getInt("maxLp")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("lp")+"/"+result.getJSONObject("results").getJSONObject("p1").getInt("maxLp")+"</td></tr>" +
"<tr><th>D-Mark</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("gold")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("gold")+"</td></tr>" +
"<tr><th>Respekt Spieler</th><td>"+result.getJSONObject("results").getJSONObject("p2").getInt("hp")+"</td><td>"+result.getJSONObject("results").getJSONObject("p1").getInt("hp")+"</td></tr>" +
"</table>" +

"<table border=\"1\">" + 
"<tr><th>Geld</th><td>"+opponent.getString("gold")+"</td></tr>" +
"<tr><th>Bank</th><td>"+opponent.getString("bank_gold")+"</td></tr>" +
"<tr><th>Training</th><td>"+opponent.getString("TrainingStats")+"</td></tr>" +
"<tr><th>Zwerge</th><td>"+opponent.getString("powercrystals")+"</td></tr>" +
"<tr><th>Respekt</th><td>"+opponent.getString("hp")+"</td></tr>" +
"<tr><th>Strategie</th><td>"+opponent.getString("tactic").replaceAll("[a-zA-Z]:[0-9]+:?", "").replace("\"stdClass\":2:", "").replace(";", "")+"</td></tr>" +
"<tr><th>Mukkies</th><td>"+opponent.getJSONObject("allAttrs").getString("strength")+"</td></tr>" +
"<tr><th>Schleuderkraft</th><td>"+opponent.getJSONObject("allAttrs").getString("intelligence")+"</td></tr>" +
"<tr><th>Wahrnehmung</th><td>"+opponent.getJSONObject("allAttrs").getString("skill")+"</td></tr>" +
"<tr><th>Fitness</th><td>"+opponent.getJSONObject("allAttrs").getString("endurance")+"</td></tr>" +
"<tr><th>Glück</th><td>"+opponent.getJSONObject("allAttrs").getString("cognition")+"</td></tr>" +
"<tr><th>Ablenkung</th><td>"+opponent.getJSONObject("allAttrs").getString("block")+"</td></tr>" +
"<tr><th>Fiese Chance</th><td>"+opponent.getJSONObject("allAttrs").getInt("sneaky")+"%</td></tr>" +
"<tr><th>Waffe Kampfschaden</th><td>"+opponent.getJSONObject("allAttrs").getJSONObject("_weaponDamage").getString("from")+" - "+opponent.getJSONObject("allAttrs").getJSONObject("_weaponDamage").getString("to")+"</td></tr>" +
"<tr><th>Kampfschaden</th><td>"+opponent.getJSONObject("allAttrs").getJSONObject("fightDamage").getInt("from")+" - "+opponent.getJSONObject("allAttrs").getJSONObject("fightDamage").getInt("to")+"</td></tr>" +
"<tr><th>Kampfbericht-E-Mail</th><td>"+opponent.getString("s_rcv_fight_mail")+"</td></tr>" +
"</table>" +
"</body>" +
"</html>");
			writer.flush();
			writer.close();
			
			toWrite.setWritable(true, false);
			
			return;
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}
}
