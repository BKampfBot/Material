package plan;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import control.Control;
import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public final class PlanMinuten extends PlanObject {
	private int count;

	public PlanMinuten(JSONObject object) throws FatalError {
		this.setName("Minuten");
		
		try {
			this.count = object.getInt("Minuten");
		} catch (JSONException e) {
			throw new FatalError("Config error: Minuten have to be an integer");
		}
		
		if (this.count < 0) {
			Output.error("Config: Minuten is set to 0.");
			this.count = 0;
		}
	}
	
	public final void run() throws ClientProtocolException, IOException, FatalError {
		Output.println("-> Minuten ("+this.count+")");
		
		// cut it into parts to safe session
		int count = this.count;
		while (count > 10) {
			// sleep for 10 min
			Output.noteln("Will sleep for 10 min");
			try { Thread.sleep(600000); } catch (InterruptedException e) {}
			count -= 10;
			Control.current.getCharacter();
		}
		Output.noteln("Will sleep for "+count+" min");
		try { Thread.sleep(60000*count); } catch (InterruptedException e) {}
	}
}
