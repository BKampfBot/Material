package control;

import java.util.Random;

import json.JSONObject;
import json.JSONTokener;
import output.Output;

public final class Gluecksrad {
	
	public Gluecksrad(Instance ins) {
		try {
			
			String s = ins.getString("http://www.bundeskampf.com/guild_challenge/index");
			int i = s.indexOf("var flashvars = {");
			i = s.indexOf("var flashvars = {", i+1);
			i = s.indexOf("var flashvars = {", i+1);
			s = s.substring(s.indexOf("guild_id:", i+1));
			s = s.substring(0, s.indexOf('\n'));
			final String guild_id = s.replaceAll("[^0-9]", "");
			
			
			JSONObject result = new JSONObject(
								new JSONTokener(
								ins.getString(
								"http://www.bundeskampf.com/guild_challenge/getData/" + guild_id)));
			
			if (result.getInt("gluecksrad") == 1) {
				JSONObject win = new JSONObject(
						new JSONTokener(ins.getString("http://www.bundeskampf.com/guild_challenge/gluecksrad/"+
								(new Random().nextInt(1)==1?60:-120))));
						
				
				if (win.getInt("win") == 1) {
					Output.println("Glücksrad: WIN");
				} else {
					Output.println("Glücksrad: LOST");
				}
			} else {
				Output.println("Glücksrad: done");
			}
		} catch (Exception e) {
			Output.error(e);
		}
	}
}
