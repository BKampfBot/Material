package plan;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import control.RestartLater;

import json.JSONException;
import json.JSONObject;
import output.FatalError;
import output.Output;

public class PlanObject {
	private String name;
	
	public static PlanObject get(JSONObject object) throws FatalError {
		String[] keys = JSONObject.getNames(object);
		if (keys == null || keys.length != 1) {
			throw new FatalError("Config is incorrect.");
		}
		

		if (keys[0].equalsIgnoreCase("Angriff")) {
			return new PlanAngriff(object);
		} else if (keys[0].equalsIgnoreCase("Außendienst")) {
			return new PlanAussendienst(object);
		} else if (keys[0].equalsIgnoreCase("Bank")) {
			return new PlanBank(object);
		} else if (keys[0].equalsIgnoreCase("Böse")) {
			return new PlanBoese(object);
		} else if (keys[0].equalsIgnoreCase("Minuten")) {
			return new PlanMinuten(object);
		} else if (keys[0].equalsIgnoreCase("Stopp")) {
			return new PlanStopp(object);
		} else if (keys[0].equalsIgnoreCase("Neustart")) {
			return new PlanNeustart(object);
		} else if (keys[0].equalsIgnoreCase("Arbeiten")) {
			return new PlanArbeiten(object);
		} else if (keys[0].equalsIgnoreCase("Kampf")) {
			return new PlanKampf(object);
		} else if (keys[0].equalsIgnoreCase("Beschreibung")) {
			return new PlanBeschreibung(object);
		} else if (keys[0].equalsIgnoreCase("Golden")) {
			return new PlanGolden(object);
		}
		
		throw new FatalError("Config is incorrect.");
	}
	
	protected final void setName(String name) {
		this.name = name;
	}
	
	public final String getName() {
		return this.name;
	}
	
	public void run() throws ClientProtocolException, IOException, FatalError, JSONException, RestartLater {
		Output.error(this.getClass().getName()+" does not implement run()");
	}
}
