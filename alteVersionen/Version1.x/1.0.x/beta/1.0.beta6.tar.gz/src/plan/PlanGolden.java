package plan;

import java.io.IOException;
import java.util.GregorianCalendar;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

import control.Control;
import control.Instance;

import output.FatalError;
import output.InfoFile;
import output.Output;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanGolden extends PlanObject {

	public PlanGolden(JSONObject object) throws FatalError {
		this.setName("Golden");
		
		try {
			object.getBoolean("Golden");
		} catch (JSONException e) {
			throw new FatalError("Config error: Golden config is bad");
		}
	}
	
	public final void run() throws IOException {
		Instance ins = Control.current;
		Output.println("-> Golden");
		
		if (!PlanAngriff.available(15)) {
			return;
		}
		
		ins.visit("http://www.bundeskampf.com/challenge/");
		ins.visit("http://www.bundeskampf.com/sieben/intro/");
		ins.visit("http://www.bundeskampf.com/sieben/index/");
		
		try {
			HttpResponse response;
				
			// send get
			HttpGet http = new HttpGet("http://www.bundeskampf.com/sieben/siebenData/");
				
			// Create a response handler
			response = ins.httpclient.execute(http);
			
		    
			HttpEntity resEntity = response.getEntity();

			JSONObject ob = new JSONObject(new JSONTokener(EntityUtils.toString(resEntity)));
			resEntity.consumeContent();
			
			
			try { Thread.sleep(500); } catch (InterruptedException e) {}
			
			ins.visit("http://www.bundeskampf.com/sieben/fight/"+ob.getString("lastId"));
			
			http = new HttpGet("http://www.bundeskampf.com/sieben/fightData/");

			// Create a response handler
			response = ins.httpclient.execute(http);
			resEntity = response.getEntity();
			
			Output.print("Fight with "+ob.getString("lastName")+" ("+ob.getString("lastId")+")");
			ob = new JSONObject(new JSONTokener(EntityUtils.toString(resEntity)));
			ob.remove("result");
			Output.println(ob.toString());
			if (ob.getInt("won") == 1) {
				Output.println(" - won");
			} else {
				Output.println(" - lost");
			}
			InfoFile.writeGolden(ob);
			resEntity.consumeContent();

			try { Thread.sleep(500); } catch (InterruptedException e) {}
			

			ins.visit("http://www.bundeskampf.com/sieben/");
			
			http = new HttpGet("http://www.bundeskampf.com/sieben/siebenData/");
			response = ins.httpclient.execute(http);
			resEntity = response.getEntity();
			ob = new JSONObject(new JSONTokener(EntityUtils.toString(resEntity)));

			long miliSeconds = ob.getInt("wait")*1000+1000;
			int min = Math.round(miliSeconds/60000);
			
			GregorianCalendar c = new GregorianCalendar();
			c.setTimeInMillis(new GregorianCalendar().getTimeInMillis()+miliSeconds);
			
			Output.println("Will sleep for "+min+" Min ("+(c.getTime().toString())+")");
			
			try { Thread.sleep(miliSeconds); } catch (InterruptedException e) {}
			
		} catch (JSONException e) {
			Output.println("No fight availible");
			Output.println(e.getInputString());
			e.printStackTrace();
		}
	}
}
