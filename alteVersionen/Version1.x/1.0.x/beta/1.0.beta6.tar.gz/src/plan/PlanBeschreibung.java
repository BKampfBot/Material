package plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.Control;
import output.FatalError;
import output.Output;
import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanBeschreibung extends PlanObject {
	private String content = "Ich war bisher zu faul eine Beschreibung einzugeben, hole ich aber sicher bald nach!";

	public PlanBeschreibung(JSONObject object) throws FatalError {
		this.setName("Beschreibung");
		
		try {
			try {
				object.getBoolean("Beschreibung");
			} catch (JSONException e) {
				this.content = object.getString("Beschreibung");
			}
		} catch (JSONException e) {
			throw new FatalError("Config error: Beschreibung have to be true or String");
		}
	}
	
	public final void run() throws IOException {
		Output.print("-> Beschreibung");
		try {
			HttpEntity entity = Control.current.get("http://www.bundeskampf.com/characters/index");
			if (entity != null) {
				String page = EntityUtils.toString(entity);
				int pos = page.indexOf("id=\"char_description\"");
				if (pos == -1) {
					throw new ParseException();
				}
				
				page = page.substring(pos);
				page = page.substring(page.indexOf("<br/>")+5);
				page = page.substring(0, page.indexOf("</span>"));
				
		        page = StringEscapeUtils.unescapeHtml(page);
				//Output.println(page);
				
				
				if (page.length() > 2 && page.charAt(0) == '{') {
					
					try {
						JSONTokener js = new JSONTokener(page);
						JSONObject result = new JSONObject(js);
						JSONArray tasks = result.getJSONArray("Befehl");
						
						PlanObject[] plan = new PlanObject[tasks.length()];
						
						for (int i=0; i<tasks.length(); i++) {
							plan[i] = PlanObject.get(tasks.getJSONObject(i));
						}
						Output.println(" (get tasks)");
						this.changeDescription("Jo, mache ich ;-)");
						
						String output = "";
						for (int i=0; i<tasks.length(); i++) {
							try {
								plan[i].run();
							} catch (Exception e) {
								output += "\nBei "+plan[i].getName()+" ging was schief";
							}
						}

						this.changeDescription(this.content + output);
						return;
					} catch (FatalError e) {
						this.changeDescription("-"+e.getMessage()+"\n"+page);
						Output.println(" (failed - bad config)");
						return;
					} catch (JSONException e) {
						this.changeDescription("-"+e.getMessage()+"\n"+page);
						Output.println(" (failed - bad config)");
						return;
					}
					
				// Beta 5
				// Only "Kampf"-Array
				} else if (page.length() > 2 && page.charAt(0) == '[') {
					
					try {
						page = "{\"Liste\":"+page+"}";
						
						JSONTokener js = new JSONTokener(page);
						JSONObject result = new JSONObject(js);
						JSONArray list = result.getJSONArray("Liste");
						
						PlanObject[] plan = new PlanObject[list.length()];
						
						for (int i=0; i<list.length(); i++) {
							plan[i] = PlanObject.get(new JSONObject(new JSONTokener("{\"Kampf\":\""+list.getString(i)+"\"}")));
						}
						Output.println(" (get fight list)");
						this.changeDescription("Jo, die mache ich platt ;-)");
						
						String output = "";
						for (int i=0; i<list.length(); i++) {
							try {
								plan[i].run();
							} catch (Exception e) {
								output += "\nBei "+plan[i].getName()+" ging was schief";
							}
						}

						this.changeDescription(this.content + output);
						return;
					} catch (FatalError e) {
						this.changeDescription("-"+e.getMessage()+"\n"+page);
						Output.println(" (failed - bad config)");
						return;
					} catch (JSONException e) {
						this.changeDescription("-"+e.getMessage()+"\n"+page);
						Output.println(" (failed - bad config)");
						return;
					}
				} else {
					Output.println(" (no task)");
				}
			}
		} catch (ParseException e) {
			Output.println(" (failed)");
		}
	}
		
	private final void changeDescription(String input) throws IOException {
		HttpEntity resEntity;
		
		// Post senden
		HttpPost http = new HttpPost("http://www.bundeskampf.com/characters/showEditDescription");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("submit", "einfügen"));
		
		http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		
		// Create a response handler
		HttpResponse response = Control.current.httpclient.execute(http);
		resEntity = response.getEntity();
		
		if (resEntity != null) {
			resEntity.consumeContent();

			http = new HttpPost("http://www.bundeskampf.com/characters/editDescription");
			nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("data[Character][description]", input));
			nvps.add(new BasicNameValuePair("submit", ""));
			
			http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			
			// Create a response handler
			response = Control.current.httpclient.execute(http);
			resEntity = response.getEntity();
			
			if (resEntity != null) resEntity.consumeContent();
		}
	}
}
