package control;

import java.io.IOException;

import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

import output.Output;


public final class ScratchTicket {
	private Instance instance;

	public ScratchTicket(Instance ins) throws IOException {
		this.instance = ins;

		for (int i=0; i<3; i++) {
			try {
				
				this.instance.visit("http://www.bundeskampf.com/kiosk/");
				this.instance.visit("http://www.bundeskampf.com/kiosk/losKaufen/");
				this.instance.visit("http://www.bundeskampf.com/kiosk/lose/");
	
				HttpGet httpget = new HttpGet("http://www.bundeskampf.com/kiosk/getLos");
				
				// Create a response handler
				HttpResponse response = this.instance.httpclient.execute(httpget);
			    
				HttpEntity resEntity = response.getEntity();
	
				if (resEntity != null) {
					JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
					JSONObject result = new JSONObject(js);
					if (resEntity != null) {
						resEntity.consumeContent();
					}
					String type = result.getString("type");
					if (!type.equals("kein Gewinn")) {
						Output.println("Lot: WIN "+ type + ": "+result.getString("data"));
					}
					type = result.getString("extratype");
					if (!type.equals("kein Gewinn")) {
						Output.println("Lot: WIN "+ type + ": "+result.getString("extradata"));
					}
				}
				try { Thread.sleep(1500); } catch (InterruptedException e) {}
				
				this.instance.visit("http://www.bundeskampf.com/kiosk/getLosWin");
			} catch (JSONException e) {
				Output.println("All scratch tickets for today");
				return;
			}
		}
	}
}
