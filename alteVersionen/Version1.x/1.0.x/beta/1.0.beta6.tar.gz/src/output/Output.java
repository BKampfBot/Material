package output;

import java.util.Calendar;
import java.util.GregorianCalendar;

import control.Control;
import control.User;

public final class Output {

	public final static void error(String string) {
		System.err.print(string + "\n");
	}

	public final static void print(String string) {
		if (Control.current != null && Control.current.getOutput()>=1)
			System.out.print(string);
	}
	
	public final static void println(String string) {
		Output.print(string+"\n");
	}
	
	public final static void note(String string) {
		if (Control.current != null && Control.current.getOutput()>=2)
			System.out.print(string);
	}
	
	public final static void noteln(String string) {
		Output.note(string + "\n");
	}

	public final static void help() {
		System.out.print(
			"Bundeskampf-Bot - Version: " + Control.version + "\n" +
			"\n" +
			"Aufruf: Bundeskampf.jar [Optionen]\n" +
			"        Bundeskampf.jar [Optionen] quiz\n" +
			"        Bundeskampf.jar [Optionen] los\n" +
			"        Bundeskampf.jar [Optionen] lotto\n" +
			"\n" +
			"Optionen:\n" +
			"  --help  -h     Zeigt diese Hilfe an\n" +
			"  --config=FILE  Nimmt FILE als Konfiguration\n" +
			"\n" +
			"Weitere Hinweise auf http://www.georf.de/bundeskampf\n");
		System.exit(0);
	}

	public final static void error(Exception e) {
		String message = "An error occured:\n" + e.getMessage() + "\n";
		StackTraceElement[] trace = e.getStackTrace();
		for (StackTraceElement elem:trace) {
			message += elem.toString() + "\n";
		}
		Output.error(message + "\n\n");
	}

	public final static void user(User user) {
		Calendar c = new GregorianCalendar();
		String time = "" + c.get(GregorianCalendar.HOUR_OF_DAY);
		if (time.length() == 1) time = "0" + time;
		time += ":" + c.get(GregorianCalendar.MINUTE);
		if (time.length() == 4) time = time.substring(0, 3) + "0" + time.substring(3);
		Output.noteln("------" + time + "-----------");
		if (user.getFights() > 0) Output.noteln("My fights: \t"+user.getFights());
		if (user.getWinMoney() > 0) Output.noteln("My win Money: \t"+user.getWinMoney());
		if (user.getLostMoney() > 0) Output.noteln("My lost Money: \t"+user.getLostMoney());
		Output.noteln("My level: \t"+user.getLevel());
		Output.noteln("My livepoints:\t"+user.getCurrentLivepoints()+"/"+user.getLivepoints());
		Output.noteln("My race:\t"+user.getRace());
		if (user.getPlaceOfHonor() > 0) Output.noteln("My place of honor:\t"+user.getPlaceOfHonor());		
	}
}
