package plan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.Control;
import control.Instance;

import output.FatalError;
import output.Output;
import json.JSONException;
import json.JSONObject;

public final class PlanBank extends PlanObject {
	private int money;

	public PlanBank(JSONObject object) throws FatalError {
		this.setName("Bank");
		
		try {
			this.money = object.getInt("Bank");
		} catch (JSONException e) {
			throw new FatalError("Config error: Bank have to be an integer");
		}
		
		if (this.money < 0) {
			Output.error("Config: Bank is set to 0.");
			this.money = 0;
		}
	}
	

	public final void run() throws ClientProtocolException, IOException {
		Output.println("-> Bank");

		Instance i = Control.current;
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/sparkasse/banker");
		
		// Create a response handler
		HttpResponse response = i.httpclient.execute(httpget);
	    
		HttpEntity resEntity = response.getEntity();
		
		String moneyMax="", moneyNow="";

		if (resEntity != null) {
			String pageContent = EntityUtils.toString(resEntity);
			int first = pageContent.indexOf("<div style=\"width:137px; height:45px; position:absolute; top:35px; left:103px; font-size:25px; color:#d3ffcb; z-index:10000;\">");
			first = pageContent.indexOf("<center>", first);
			first += "<center>".length();
			int end = pageContent.indexOf("</center>", first);
			moneyNow = pageContent.substring(first, end);
		
			httpget = new HttpGet("http://www.bundeskampf.com/sparkasse/einzahlen");
			response = i.httpclient.execute(httpget);
		    
			resEntity = response.getEntity();

			if (resEntity != null) {
				pageContent = EntityUtils.toString(resEntity);
				
				if (pageContent.indexOf("D-Mark haben um etwas einzuzahlen.") != -1) {
					Output.noteln("Not enough money for the bank.");
					return;
				}
				
				first = pageContent.indexOf("name=\"data[Bank][in]\"");
				first = pageContent.indexOf("to=\"", first);
				first += "to=\"".length();
				end = pageContent.indexOf("\"", first);
				moneyMax = pageContent.substring(first, end);

		        // Post senden
				HttpPost http = new HttpPost("http://www.bundeskampf.com/sparkasse/einzahlen");
				List <NameValuePair> nvps = new ArrayList <NameValuePair>();
				
				if (this.money == 0 || this.money > Integer.parseInt(moneyMax)) {
					nvps.add(new BasicNameValuePair("data[Bank][in]", moneyMax));
				} else {
					moneyMax = String.valueOf(this.money);
					nvps.add(new BasicNameValuePair("data[Bank][in]", moneyMax));
				}
				nvps.add(new BasicNameValuePair("x","161"));
				nvps.add(new BasicNameValuePair("y","32"));
				
				http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
				// Create a response handler
				response = i.httpclient.execute(http);
				resEntity = response.getEntity();

				if (resEntity != null) {
					resEntity.consumeContent();
				}
				
			}
			httpget = new HttpGet("http://www.bundeskampf.com/sparkasse/banker");
			
			// Create a response handler
			response = i.httpclient.execute(httpget);
		    
			resEntity = response.getEntity();

			if (resEntity != null) {
				pageContent = EntityUtils.toString(resEntity);
				first = pageContent.indexOf("<div style=\"width:137px; height:45px; position:absolute; top:35px; left:103px; font-size:25px; color:#d3ffcb; z-index:10000;\">");
				first = pageContent.indexOf("<center>", first);
				first += "<center>".length();
				end = pageContent.indexOf("</center>", first);
				moneyNow = pageContent.substring(first, end);
			}
		}
		
		Output.noteln("Put "+moneyMax+" to bank. Now: "+moneyNow);
	}
}
