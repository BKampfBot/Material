package control;

import output.FatalError;
import output.Output;

public class Control {
	public final static String version = "1.0.beta2"; 
	
	public final static String[] userAgents = {
			"Mozilla/5.0 (X11; U; Linux i686; de; rv:1.9.1.5) Gecko/20091109 Ubuntu/9.10 (karmic) Firefox/3.5.5",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20100106 Ubuntu/9.10 (karmic) Firefox/3.5.7",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20091215 Ubuntu/9.10 (karmic) Firefox/3.5.6",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20091102 Ubuntu/9.10 (karmic) Firefox/3.5.5",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20091019 Ubuntu/9.10 (karmic) Firefox/3.5.4",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090824 Ubuntu/9.10 (karmic) Firefox/3.5.3",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090730 Ubuntu/9.10 (karmic) Firefox/3.5.2",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090717 Ubuntu/9.10 (karmic) Firefox/3.5.1",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090720 Ubuntu/9.10 (karmic) Firefox/3.0.12",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090610 Ubuntu/9.10 (karmic) Firefox/3.0.11",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090427 Ubuntu/9.10 (karmic) Firefox/3.0.10",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090409 Ubuntu/9.10 (karmic) Firefox/3.0.9",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090327 Ubuntu/9.10 (karmic) Firefox/3.0.8",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090303 Ubuntu/9.10 (karmic) Firefox/3.0.7",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20090202 Ubuntu/9.10 (karmic) Firefox/3.0.6",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20081215 Ubuntu/9.10 (karmic) Firefox/3.0.5",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20081111 Ubuntu/9.10 (karmic) Firefox/3.0.4",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20081007 Ubuntu/9.10 (karmic) Firefox/3.0.3",
			"Mozilla/5.0 (X11; U; Linux i686; de;) Gecko/20080922 Ubuntu/9.10 (karmic) Firefox/3.0.2",
	};
	
	public final static String databaseUri = "http://www.georf.de/others/quiz1.php?";
	
	public final static int maxFights = 10;
	
	public static Instance current = null;
	
	public final static void main(String[] args) {
		for (int i=0; i<20; i++) {
			try {
				Control.current = new Instance(args);
				current.run();
			} catch (FatalError e) {
				Output.error(e.getMessage() + "\n");
				System.exit(1);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public final static void safeExit() {
		// logout
		Control.current.logout();
		System.exit(0);
	}

}
