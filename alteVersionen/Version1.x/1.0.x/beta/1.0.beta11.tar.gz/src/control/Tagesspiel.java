package control;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import output.Output;


public final class Tagesspiel {
	
	public Tagesspiel(Instance ins) throws ClientProtocolException, IOException, NoSuchAlgorithmException {
		String page = ins.getString("http://www.bundeskampf.com/city/index");
		
		// Komische Figur schon abgeschossen?
		if (page.indexOf("win: \"1\"") != -1) {
			Output.println("Try to hit opponent in the city");
			
			try { Thread.sleep(3000); } catch (InterruptedException e) {}
			
			HttpPost http = new HttpPost("http://www.bundeskampf.com/city/winning");
			List <NameValuePair> nvps2 = new ArrayList <NameValuePair>();
			nvps2.add(new BasicNameValuePair("hallo", "1"));
			
			http.setEntity(new UrlEncodedFormEntity(nvps2, HTTP.UTF_8));
			// Create a response handler
			HttpResponse post = ins.httpclient.execute(http);
			HttpEntity resEntity = post.getEntity();
			if (resEntity != null) {
				String resulte = EntityUtils.toString(resEntity);
				if (resulte.equals("{\"success\":1}")) {
					Output.println("Get 10 Fleispunkte");
				}
				resEntity.consumeContent();
			}
		}
		
		try {
			
			page = ins.getString("http://www.bundeskampf.com/games");
			
			if (page.indexOf("<img src=\"http://www.bundeskampf.com/layout/game.png\"") == -1) {
				Output.println("Tagesquiz: DONE");
				return;
			}
			page = page.substring(page.indexOf("<img src=\"http://www.bundeskampf.com/layout/game.png\"")-50);
			
			page = page.substring(0, 50);
			page = page.substring(page.indexOf("<a href=\""));
			page = page.replaceAll("[^0-9]", "");

			ins.visit("http://www.bundeskampf.com/games/play/"+page);
			ins.visit("http://www.bundeskampf.com/games/getGame");

			int wait = new Random().nextInt(30)+30;
			Output.noteln("Wait "+wait+" seconds");
			try { Thread.sleep(wait*1000); } catch (InterruptedException e) {}
			
			final int fleis = 15; 
			
			page = ins.getString("http://www.bundeskampf.com/games/punkte/" + fleis + "/" + ((1177 + fleis) * 177 + 77) * fleis);
			JSONObject result = new JSONObject(new JSONTokener(page));
			if (result.getInt("result") == 1) {
				Output.println("Tagesquiz: WIN");
			} else {
				Output.println("Tagesquiz: LOST");
			}
		} catch (JSONException e) {
			Output.error(e);
			return;
		}
	}
}