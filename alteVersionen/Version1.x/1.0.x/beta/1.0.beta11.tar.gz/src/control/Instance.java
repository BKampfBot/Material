package control;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import control.User.Status;

import json.JSONArray;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

import output.FatalError;
import output.InfoFile;
import output.Output;
import plan.PlanAngriff;
import plan.PlanArbeiten;
import plan.PlanAussendienst;
import plan.PlanBoese;
import plan.PlanObject;

public class Instance {
	
	public enum Modus { normal, daily, help, lottery, pins }
	public enum Daily { quiz, scratchTicket, glueck, wein, spiel }
	
	// Configuration
	private String password = null;
	private String username = null;
	private int	output = 2;
	private PlanObject[] plan0 = null;
	private PlanObject[] plan1 = null;

	private int moneyFightAgain = 10;
	
	private String configFile = "config.json";
	private Modus modus = Modus.normal;
	private Daily[] daily;
	
	// Instance
	public DefaultHttpClient httpclient;
	public User user;
	

	public Instance(String[] args) throws FatalError, IOException {
		
		// configure plans
		PlanBoese.initiate();
		PlanAngriff.initiate();
		
		
		this.parseArguments(args);
		
		if (this.modus.equals(Modus.help)) {
			Output.help();
		}
		
		// read config file
		try {
			File f = new File(this.configFile);
			FileInputStream fstream = new FileInputStream(f.getAbsoluteFile());
			DataInputStream in = new DataInputStream(fstream);
	        BufferedReader br = new BufferedReader(new InputStreamReader(in));
	    
	        String strLine, configString = "";
	    
	        //Read File Line By Line
	        while ((strLine = br.readLine()) != null) {
	        	if (strLine.length() > 0 && strLine.substring(0, 1).equals("#")) {
	        		continue;
	        	}
	        	configString += strLine;
	        }
	    
	        //Close the input stream
	        in.close();
	        
			// make to JSONObject
	        configString = "{" + configString + "}";

	        try {
				JSONObject config = new JSONObject(new JSONTokener(configString));
				String[] configKeys = JSONObject.getNames(config);
				
				for (String key:configKeys) {
					if (key.equalsIgnoreCase("Benutzername")) {
						this.username = config.getString(key);
					} else if (key.equalsIgnoreCase("Passwort")) {
						this.password = config.getString(key);
					} else if (key.equalsIgnoreCase("Ausgabe")) {
						this.output = config.getInt(key);
					} else if (key.equalsIgnoreCase("Angriff nochmal")) {
						this.moneyFightAgain = config.getInt(key);
					} else if (key.equalsIgnoreCase("Außendienst verfügbar")) {
						JSONArray plan = config.getJSONArray(key);
						this.plan0 = new PlanObject[plan.length()];
						
						for (int i=0; i<plan.length(); i++) {
							this.plan0[i] = PlanObject.get(plan.getJSONObject(i));
						}
					} else if (key.equalsIgnoreCase("Kein Außendienst")) {
						JSONArray plan = config.getJSONArray(key);
						this.plan1 = new PlanObject[plan.length()];
						
						for (int i=0; i<plan.length(); i++) {
							this.plan1[i] = PlanObject.get(plan.getJSONObject(i));
						}
					} else if (key.equalsIgnoreCase("Info Pfad")) {
						InfoFile.path = config.getString(key);
						InfoFile.initiate();
					}
				}
			} catch (JSONException e) {
				throw new FatalError("Innerhalb der Konfigurationsdatei trat ein Fehler auf. Die Struktur stimmt nicht.\n" +
						" 1. Möglichkeit:\n" +
						"    Entweder stehen die Steuerzeichen nicht in der richtigen Reihenfolge.\n" +
						" 2. Möglichkeit:\n" +
						"    In der Vergangenheit traten auch viele Fehler mit der Codierung auf. Die Konfiguration sollte mit UTF-8 ohne BOM codiert werden.\n" +
						"\nAls Hinweis hier noch die Fehlerausgabe:\n" + e.getMessage() + "\nString was:\n"+e.getInputString());
			}
		} catch (FileNotFoundException e) {
			throw new FatalError("Die Konfigurationsdatei konnte nicht gefunden/geöffnet werden.\n Datei: " + this.configFile + "\n Fehler: "+e.getMessage());
		}
		
		if (this.password == null 
		|| 	this.username == null) {
			throw new FatalError("Die Konfigurationsdatei ist nicht vollständig. Es wird mindestens der Benutzername und das Passwort benötigt.");
		}
		
	   
	}
	
	/**
	 * Sucht den Benutzer in der WildeKeilereiListe und gibt die Angriffsurl zurück
	 * 
	 *  @param Name des Gegners
	 *  @return Url zum Kämpfen
	 *  @throws ClientProtocolException {@link IOException}
	 */
	public final String findAttackByName(String name) throws ClientProtocolException, IOException {
		
		HttpResponse response;
			
		// send post 
		HttpPost http = new HttpPost("http://www.bundeskampf.com/fights/searchCharacterJson");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("playerName", name));
			
		http.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		// Create a response handler
		response = this.httpclient.execute(http);
			
		    
		HttpEntity resEntity = response.getEntity();
		JSONArray arr;

		if (resEntity != null) {
			String s = EntityUtils.toString(resEntity);
			try {
				JSONTokener js = new JSONTokener(s);
				JSONObject ob = new JSONObject(js);
			
				arr = ob.getJSONArray("list");
				resEntity.consumeContent();
				for (int i=0; i<arr.length(); i++) {
					JSONObject player = arr.getJSONObject(i);
					if (player.getString("name").equalsIgnoreCase(name)) {
						return player.getString("attack");
					}
				}
				Output.println("Player "+name+" not found");
				return null;
			} catch (JSONException e) {
				Output.println("Player "+name+" not found");
				return null;
			}
		}
		return null;
	}
	
	public final String findAttackById(String id) throws ParseException, IOException {
		HttpEntity entity = this.get("http://www.bundeskampf.com/characters/profile/"+id);
		if (entity != null) {
			String page = EntityUtils.toString(entity);

			int pos = page.indexOf("href=\"/fights/start/");
			if (pos == -1) return null;
			page = page.substring(pos);
			page = page.substring(0, page.indexOf("<img"));

			Pattern p = Pattern.compile("/fights/start/([0-9]+)\"", Pattern.MULTILINE);
			Matcher m = p.matcher(page);
			if (m.find())
				return "/fights/start/"+m.group(1);
		}
		return null;
	}
	
	public final int fight(String attack, String name, String method) throws BadOpponent, IOException {
		this.visit("http://www.bundeskampf.com/fights/fight");
		this.visit("http://www.bundeskampf.com"+attack);
		
		Output.print("Fight with "+name);
		
		try { Thread.sleep(500); } catch (InterruptedException e) {}
		
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/fights/fightData");
	
		// Create a response handler
		HttpResponse response = this.httpclient.execute(httpget);
		    
		HttpEntity resEntity = response.getEntity();
	
		int returnValue = -1;
		
		if (resEntity != null) {
			try {
				JSONTokener js = new JSONTokener(EntityUtils.toString(resEntity));
				JSONObject fight = new JSONObject(js);
				if (resEntity != null) {
					resEntity.consumeContent();
				}
	
				httpget = new HttpGet(
					"http://www.bundeskampf.com" +
					fight.getString("url").replace("/results/","/getResults/"));
	
				// Create a response handler
				response = this.httpclient.execute(httpget);
			    
				resEntity = response.getEntity();
	
				if (resEntity != null) {
					String s = EntityUtils.toString(resEntity);
					//Main.debug("Fightresult: "+s+"\n____\n");
					js = new JSONTokener(s);
					fight = new JSONObject(js);
					
					InfoFile.writeFightFile(fight, method);
					
					JSONObject res = fight.getJSONObject("results");
					JSONObject p1 = res.getJSONObject("p1");
					
					Output.print(" hp:"+p1.getInt("hp"));
					
					if (res.getBoolean("fightWasWon")) {
						Output.println(" - won ("+p1.getInt("gold")+")");
						this.user.addWinMoney(p1.getInt("gold"));	
						
						returnValue = p1.getInt("gold");
					} else {
						Output.println(" - lost ("+p1.getInt("gold")+")");
						this.user.addLostMoney(p1.getInt("gold"));		
					}
					
					this.user.setLevel(Integer.parseInt(fight.getString("mylevel")));
					this.user.setCurrentLivepoints(Integer.parseInt(p1.getString("lp")));
					this.user.setLivepoints(Integer.parseInt(p1.getString("maxLp")));
					this.user.setPlaceOfHonor(p1.getJSONObject("PlaceOfHonour").getInt("after"));
	
					JSONObject time = fight.getJSONObject("aTime");
					GregorianCalendar c = new GregorianCalendar(Integer.parseInt(time.getString("toYear")),
									Integer.parseInt(time.getString("toMonth"))-1,
									Integer.parseInt(time.getString("toDay")),
									Integer.parseInt(time.getString("toHour")),
									Integer.parseInt(time.getString("toMinute")),
									Integer.parseInt(time.getString("toSecond")));

					long milli = c.getTimeInMillis()-new GregorianCalendar().getTimeInMillis();
					
					// Add 20 seconds
					milli += 20000;
					
					if (resEntity != null) {
						resEntity.consumeContent();
					}
					
					Output.user(this.user);
					
					Output.println(
						"Will sleep for " + Math.round(milli/(1000*60)) + " minutes (" +
						new SimpleDateFormat("hh:mm").format(c.getTime()) +")");
					try { Thread.sleep(milli); } catch (InterruptedException e) {}
					this.visit("http://www.bundeskampf.com/fights/start");
				}
				return returnValue;
			} catch (JSONException e) {
				Output.println(" - nothing");
				throw new BadOpponent(attack, name);
			}
		}
		return -1;
	}
	
	private final boolean finishOldWork() throws ClientProtocolException, IOException, FatalError {
		Output.noteln("Try to finish your old task.");
		boolean returnValue = false;
		
		switch (this.user.getStatus()) {
			case work:
				returnValue = PlanArbeiten.finish();
				break;
				
			case service:
				returnValue = PlanAussendienst.finish();
				break;
				
			case training:
				Output.println("Try to finish training.");
				this.visit("http://www.bundeskampf.com/training");
				returnValue = true;
				break;
				
			case nothing:
			default:
				returnValue = true;
				break;
		}
		
		this.getCharacter();
		return returnValue;
	}

	
	public final void getCharacter() throws ClientProtocolException, IOException, FatalError {
		this.getCharacter(false);
	}
	
	private final void getCharacter(boolean login) throws ClientProtocolException, IOException, FatalError {
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/characters/index");
		httpget.addHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		httpget.addHeader("Accept-Language","de-de,de;q=0.8,en-us;q=0.5,en;q=0.3");
		//httpget.addHeader("Accept-Encoding","deflate");
		httpget.addHeader("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
		httpget.addHeader("Keep-Alive","300");
		
		if (login) {
			httpget.addHeader("Referer","http://www.bundeskampf.com/signups/login");
		}
		
		String s = "";
		
		try {
			// Create a response handler
			HttpResponse response = this.httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				s = EntityUtils.toString(entity);
	
				this.testStatus(s);
	
				int navi2 = s.indexOf("/img/flash/navi_or2.swf");
				navi2 = s.indexOf("flashvars", navi2+1);
				navi2 = s.indexOf("flashvars", navi2+1);
				int lineFront = s.indexOf('{', navi2);
				int lineEnd = s.indexOf(';', lineFront+1);
				String s2 = s.substring(lineFront+1, lineEnd+1);
				s2 = "{"+s2;
	
				JSONTokener tk = new JSONTokener(s2);
				JSONObject character = new JSONObject(tk);
				this.user.setLevel(Integer.parseInt(character.getString("lvl")));
				this.user.setLivepoints(Integer.parseInt(character.getString("max_lp")));
				this.user.setCurrentLivepoints(Integer.parseInt(character.getString("lp")));
	
				// try to find race
				s2 = "<b>Bundesland:</b> </span><br/><span style=\"color:#000000; font-size:12px;\">";
	
				lineFront = s.indexOf(s2);
				lineEnd = s.indexOf('<',lineFront+1+s2.length());
				
				this.user.setRace(s.substring(lineFront+s2.length()+1, lineEnd-1));
				// Output.user(user);
			}
		} catch (JSONException e) {
			if (s.contains("form action=\"/signups/login\" method=\"post\"")) {
				throw new FatalError("Login failed");
			}
			String message = "Get an error at initiation\n";
			if (login) {
				message +=
					"Reason 1: Login failed\n" +
					"Reason 2: Something on server side changed.\n";
			} else {
				message += "Possible reason: Something on server side changed.\n";
			}
			
			message += "\n" +
				"If you want to report a bug, please post this:\n\n" + 
				e.getMessage() + "\n";
			
			StackTraceElement[] trace = e.getStackTrace();
			for (StackTraceElement elem:trace) {
				message += elem.toString() + "\n";
			}
			throw new FatalError(message + "\nResponse was:\n" + s);
		}
	}

	public final int getMoneyFightAgain() {
		return this.moneyFightAgain;
	}
	
	public final int getOutput() {
		return output;
	}
	
	private final void login() throws ClientProtocolException, IOException, FatalError {
		Output.println("Login");
		
		this.user = new User();
	        
        // create post data
		HttpPost httppost = new HttpPost("http://www.bundeskampf.com/signups/login/");
			
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("data[Signup][name]", this.username));
		nvps.add(new BasicNameValuePair("data[Signup][pass]", this.password));
		nvps.add(new BasicNameValuePair("Einloggen.x", "67"));
		nvps.add(new BasicNameValuePair("Einloggen.y", "18"));
			
		httppost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		httppost.addHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		httppost.addHeader("Accept-Language","de-de,de;q=0.8,en-us;q=0.5,en;q=0.3");
		httppost.addHeader("Accept-Encoding","gzip,deflate");
		httppost.addHeader("Accept-Charset","ISO-8859-1,utf-8;q=0.7,*;q=0.7");
		httppost.addHeader("Keep-Alive","300");
		httppost.addHeader("Referer","http://www.bundeskampf.com/signups/login");
			
		// send post
		HttpResponse response = this.httpclient.execute(httppost);
		HttpEntity entity = response.getEntity();
			
		if (entity != null) {
		    entity.consumeContent();
		}

		this.getCharacter(true);
	}

	public final void logout() {
		Output.println("Logout");
		this.visit("http://www.bundeskampf.com/signups/logout");		
	}
	
	private final void parseArguments(String[] args) {
		this.daily = new Daily[args.length];
		int dailyCount = 0;

		for (String arg : args) {
			if (arg.equals("quiz") && (this.modus.equals(Modus.normal) || this.modus.equals(Modus.daily))) {
				this.modus = Modus.daily;
				this.daily[dailyCount] = Daily.quiz;
				dailyCount++;
				
				Output.noteln("set daily: quiz");
			}

			if (arg.equals("los") && (this.modus.equals(Modus.normal) || this.modus.equals(Modus.daily))) {
				this.modus = Modus.daily;
				this.daily[dailyCount] = Daily.scratchTicket;
				dailyCount++;

				Output.noteln("set daily: los");
			}

			if (arg.equals("lotto") && this.modus.equals(Modus.normal)) {
				this.modus = Modus.lottery;
			}

			if (arg.length() > 5 && arg.substring(0,5).equalsIgnoreCase("pins=") && this.modus.equals(Modus.normal)) {
				Pins.in = arg.substring(5);
				this.modus = Modus.pins;
			}
			
			if (arg.equals("glueck") && (this.modus.equals(Modus.normal) || this.modus.equals(Modus.daily))) {
				this.modus = Modus.daily;
				this.daily[dailyCount] = Daily.glueck;
				dailyCount++;
				
				Output.noteln("set daily: glueck");
			}
			
			if (arg.equals("wein") && (this.modus.equals(Modus.normal) || this.modus.equals(Modus.daily))) {
				this.modus = Modus.daily;
				this.daily[dailyCount] = Daily.wein;
				dailyCount++;
				
				Output.noteln("set daily: wein");
			}
			
			if (arg.equals("spiel") && (this.modus.equals(Modus.normal) || this.modus.equals(Modus.daily))) {
				this.modus = Modus.daily;
				this.daily[dailyCount] = Daily.spiel;
				dailyCount++;
				
				Output.noteln("set daily: spiel");
			}
			
			if (arg.length() > 9 && arg.substring(0,9).equalsIgnoreCase("--config=")) {
				this.configFile = arg.substring(9);
			}
			
			if (arg.length() > 9 && arg.substring(0,9).equalsIgnoreCase("--output=")) {
				try {
					this.output = Integer.valueOf(arg.substring(9));
				} catch (NumberFormatException e) {
					Output.error("Output-Level muss 0,1 oder 2 sein");
				}
			}
			
			if (arg.equals("--help") || args.equals("-h")) {
				this.modus = Modus.help;
			}
		}
	}

	
	public final void run() throws ClientProtocolException, IOException, FatalError, JSONException, RestartLater, NoSuchAlgorithmException {
		
		// initialization HTTP client

		this.httpclient = new DefaultHttpClient();
		
		final HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setUseExpectContinue(params, false);
		
		Random generator = new Random();
		HttpProtocolParams.setUserAgent(params, 
				Control.userAgents[generator.nextInt(Control.userAgents.length)]);
		
		this.httpclient.setParams(params);
		this.httpclient.getParams().setParameter(ClientPNames.COOKIE_POLICY,  
				CookiePolicy.BROWSER_COMPATIBILITY);
		
		
		// login
		this.login();
		
		
		switch (this.modus) {
		
			// call help
			case help:
				Output.help();
				Control.safeExit();
				break;
				
			case daily:
				
				for(Daily d : this.daily) {
					switch (d) {
						// call "Rubbellos"
						case scratchTicket:
							new ScratchTicket(this);
							break;
				
						// call "Tagesquiz"
						case quiz:
							new Quiz(this);
							break;
							
						// call "Lotto"
						case glueck:
							new Gluecksrad(this);
							break;

							
						// call "Weinfässer"
						case wein:
							new Wein(this);
							break;


						
						// call "Tagesspiel"
						case spiel:
							new Tagesspiel(this);
							break;
									
					}
				}
				Control.safeExit();
				break;

			// call "Lotto"
			case lottery:
				new Lottery(this, true);
				Control.safeExit();
				break;

			// call "Lotto"
			case pins:
				new Pins(this);
				Control.safeExit();
				break;
					
				
			// call "Plan"
			default:
			case normal:
				
				Calendar lastCall = null;
				while (true) {
					Calendar now = new GregorianCalendar();
					now.add(Calendar.MINUTE, -2);
					if (lastCall != null && lastCall.after(now)) {
						Output.println("We are to fast. Will wait 5 mins.");
						try { Thread.sleep(300000); } catch (InterruptedException e) {}
					}
					lastCall = new GregorianCalendar();
					this.runPlans();
					
					try { Thread.sleep(500); } catch (InterruptedException e) {}
					
					this.getCharacter();
					
					try { Thread.sleep(500); } catch (InterruptedException e) {}
				}
		}	
	}

	private final void runPlans() throws ClientProtocolException, IOException, FatalError, JSONException, RestartLater {
		
		// first check for old not finished task
		if (!this.user.getStatus().equals(Status.nothing)) {
			for (int i=0; i<3 && !this.finishOldWork(); i++) {
				try { Thread.sleep(360000); } catch (InterruptedException e) {}
			}
				
			if (!this.user.getStatus().equals(Status.nothing)) {
				throw new FatalError("Can't finish old task.");
			}
		}
		
		// Ab Version 1.0.beta11 muss plan0 nicht gesetzt sein
		if (this.plan0 != null) {
			while (this.plan0.length != 0 && this.serviceAvalible() ) {
				Output.println("Go into the plan 0");
				for (int i=0; i<this.plan0.length && this.serviceAvalible(); i++) {
					this.plan0[i].run();
					Output.user(this.user);
				}
			}
		}
		
		// Ab Version 1.0.beta11 muss plan1 nicht gesetzt sein
		if (this.plan1 != null) {
			Output.println("Go into the plan 1");
			for (int i=0; i<this.plan1.length; i++) {
				if (!this.plan1[i].getName().equals("Außendienst")) {
					this.plan1[i].run();
					Output.user(this.user);
				}
			}
		}	
		PlanAngriff.showLists();
	}

	public final HttpEntity get(String url) {
		try {
			HttpGet httpget = new HttpGet(url);
			
			// Create a response handler
			HttpResponse response = this.httpclient.execute(httpget);
			    
			return response.getEntity();
		} catch (ClientProtocolException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
	}

	public final String getString(String url) {
		try {
			Output.noteln("getString: "+url);
			HttpGet httpget = new HttpGet(url);
			
			// Create a response handler
			HttpResponse response = this.httpclient.execute(httpget);
			    
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String ret = EntityUtils.toString(entity);
				if (entity != null) {
					entity.consumeContent();
				}
				return ret;
			} else {
				return "";
			}
		} catch (ClientProtocolException e) {
			return "";
		} catch (IOException e) {
			return "";
		}
	}
	
	private final boolean serviceAvalible() throws ClientProtocolException, IOException, RestartLater {
		Output.noteln("Checking for service avalible");
		HttpGet httpget = new HttpGet("http://www.bundeskampf.com/quests/start");
		
		// Create a response handler
		HttpResponse response = this.httpclient.execute(httpget);
		    
		HttpEntity resEntity = response.getEntity();		
		if (resEntity != null) {
				String page = EntityUtils.toString(resEntity);
				int pos = page.indexOf("class=\"questanzahl\"");
				if (pos == -1) {
					throw new RestartLater();
				}
				page = page.substring(pos);
				page = page.substring(0, page.indexOf("</div>"));

				Pattern p = Pattern.compile(">([0-9]+)/\\1\\s", Pattern.MULTILINE);
				Matcher m = p.matcher(page);
				
				return !m.find();
		}
		return false;
	}

	private final void testStatus(String s) {
		if(s.indexOf("/Bilderx/arbeiten.jpg")!=-1) {
			this.user.setStatus(Status.work);
			Output.noteln("Du bist gerade am Arbeiten");
		} else if (s.indexOf("/Bilderx/train.jpg")!=-1) {
			this.user.setStatus(Status.training);
			Output.noteln("Du bist gerade am Trainieren");
		} else if (s.indexOf("/Bilderx/dienst.jpg")!=-1) {
			this.user.setStatus(Status.service);
			Output.noteln("Du bist im Außendienst");
		} else {
			this.user.setStatus(Status.nothing);
		}
	}

	public final void visit(String url) {
		Output.noteln("visit: " + url);
		
		try {
			HttpGet httpget = new HttpGet(url);
	        HttpResponse response = this.httpclient.execute(httpget);
	        HttpEntity entity = response.getEntity();

	        if (entity != null) {
	            entity.consumeContent();
	        }
	        try { Thread.sleep(300); } catch (InterruptedException e) {}

		} catch(Exception e) {
			Output.error(e);
		}
	}

	public final void waitForStatus() throws ClientProtocolException, IOException, FatalError {
		this.getCharacter();
		while (this.user.getCurrentLivepoints() != this.user.getLivepoints()) {
			Output.noteln("Wait for a good status. Sleep for 30 seconds...");
			try { Thread.sleep(30000); } catch (InterruptedException e) {}
			this.getCharacter();
		}
	}
}
