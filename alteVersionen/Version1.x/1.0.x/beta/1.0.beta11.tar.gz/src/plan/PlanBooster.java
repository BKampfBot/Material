package plan;

import control.Control;
import output.FatalError;
import output.InfoFile;
import output.Output;
import json.JSONException;
import json.JSONObject;
import json.JSONTokener;

public final class PlanBooster extends PlanObject {

	private int booster;
	
	public PlanBooster(JSONObject object) throws FatalError {
		this.setName("Booster");
		try {
			this.booster = object.getInt("Booster");
		} catch (JSONException e) {
			throw new FatalError("Config error: Booster config is bad");
		}
		
		switch (this.booster) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				break;
				
			default:
				Output.error("You set a wront booster level! Will set to 1.");
				this.booster = 1;
				break;
		}
	}
	
	public final void run() {
		try {
			Output.println("-> Booster "+this.booster);
			
			String s = Control.current.getString("http://www.bundeskampf.com/guild_challenge/index");
			int i = s.indexOf("var flashvars = {");
			i = s.indexOf("var flashvars = {", i+1);
			i = s.indexOf("var flashvars = {", i+1);
			s = s.substring(s.indexOf("guild_id:", i+1));
			s = s.substring(0, s.indexOf('\n'));
			final String guild_id = s.replaceAll("[^0-9]", "");
			
			//visit http://www.bundeskampf.com/guild_challenge/index
			JSONObject result = new JSONObject(
								new JSONTokener(
								Control.current.getString(
								"http://www.bundeskampf.com/guild_challenge/getData/" + guild_id)));
			
			if (result.getInt("booster") == 1) {
				JSONObject win = new JSONObject(
						new JSONTokener(Control.current.getString(
								"http://www.bundeskampf.com/guild_challenge/booster/"+
								this.booster)));
						
				
				if (win.getInt("win") == 1) {
					Output.println("Booster: WIN");
				} else {
					Output.println("Booster: LOST");
				}
				
				InfoFile.writeLog(
					"booster:"+this.booster+"\n"+
					"win:"+win.getInt("win")+"\n"+
					"boostertimes:"+result.getInt("boostertimes")+"\n"+
					"nextbooster:"+result.getInt("nextbooster"), null);

			} else {
				Output.println("Booster is done.");
			}
		} catch (JSONException e) {
			Output.error(e);
		}
	}
}
